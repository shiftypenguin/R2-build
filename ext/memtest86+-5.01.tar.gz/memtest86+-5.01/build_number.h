#ifndef BUILD_NUMBER_STR
#define BUILD_NUMBER_STR "617"
#endif
#ifndef VERSION_STR
#define VERSION_STR "4.99617 - Thu May  3 11:45:57 CEST 2012"
#endif
#ifndef VERSION_STR_SHORT
#define VERSION_STR_SHORT "4.99617"
#endif
