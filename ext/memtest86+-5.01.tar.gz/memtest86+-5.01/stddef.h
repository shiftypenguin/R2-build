#ifndef I386_STDDEF_H
#define I386_STDDEF_H

#define NULL ((void *)0)

typedef unsigned long size_t;

#endif /* I386_STDDEF_H */
