/*	$OpenBSD: version.h,v 1.4 1996/12/10 22:22:03 millert Exp $	*/

#define FLEX_VERSION "2.5.4"
