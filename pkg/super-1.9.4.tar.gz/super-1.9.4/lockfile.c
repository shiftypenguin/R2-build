#include "super.h"

#ifdef PATH_LOCKS
int mklockfile(void)
{
	int fd;
	char *path;

	if (issuper()) {
		lockfile = NULL;
		return 1;
	}

	path = xmalloc(PATH_MAX);

/*
 * Let's lock per uid (and even not per uid/gid!).
 * User can't run another super while per uid lockfile exists,
 * even if user has another set of groups
 */
	xsnprintf(path, PATH_MAX, PATH_LOCKS "%u" PATH_LOCKS_SUF, srcuid);

/* A sanity check: is full path not truncated? */
	if (!strstr(path, "." NAME)) blame("lockfile name truncated");

	fd = open(path, O_RDWR | O_CREAT | O_EXCL, 0600);
	if (fd == -1) {
		if (errno == EEXIST) return 0;
		else blame("lockfile \"%s\" is not created: %s", path, strerror(errno));
	}

	lockfile = s_strndup(path, _ALLOC_MAX);
	if (!lockfile) {
		lockfile = path;
		unlockfile();
		xerror("mklockfile");
	}
	close(fd);

	xfree(path);

	return 1;
}

/*
 * should be called BEFORE dropping superuser rights
 *
 * should not leak files, because called from:
 * - xexit() (wipevars()), which is called from everywhere
 * - before changing uids
 *
 * should fail only when EACCES
 * should not be recursive
 */
void unlockfile(void)
{
	static int called;

	if (issuper()) return;

	if (lockfile && !called) {
		called = 1;
		if (unlink(lockfile) == -1) xerror("unlockfile");
		lockfile = NULL;
	}
}
#endif
