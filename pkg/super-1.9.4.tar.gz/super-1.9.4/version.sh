#!/bin/sh
exec 2>&-
exec 2<>/dev/null
_version=`git describe --tags`
if [ -z "${_version}" ]; then echo -U_SUPER_VERGIT; exit 0; fi
if [ `echo ${_version} | cut -d'-' -f2- -s | wc -c` -gt 0 ]; then
	echo -D_SUPER_VERGIT=\\\"${_version}\\\"
else
	echo -U_SUPER_VERGIT
fi
