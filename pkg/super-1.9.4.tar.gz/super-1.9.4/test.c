#include "super.h"

int isnum(const char *s)
{
	char *p;
	if (!s || *s == 0) return 0;
	strtol(s, &p, 10);
	return (*p == 0);
}

/* This is somehow ugly to support numeric lookups, but let it be */
int optr_isnum(const char *s)
{
	int r = isnum(s);
	if (r && isflag(optflags, SI_OPT_r)) return 0;
	return r;
}

/*
 * This checks format string for (basic) conformance.
 * Allow only n number of %'c' specifiers in string, allows double-percent.
 * This one always called for strings coming from trusted source (config file),
 * and called only in it's contexts. Any misconfigurations made by superuser
 * are not our fault, so this one will try to prevent obvious damages,
 * but it can't parse arbitrary number of printf's variants.
 * c == fmt char to match, n == how many of them, z == allow non-formatted strings
 */
int isfmtstr(const char *s, int c, int n, int z)
{
	int x = 0;

	if (z && !strchr(s, '%')) return 1;
	if (!strcmp(s, "%")) return 0;
	while (*s) {
		if (*s == '%' && !*(s+1)) break;
		if (*s == '%' && *(s+1) == '%') { s += 2; x = 1; continue; }
		if (*s == '%' && *(s+1) == c) n--;
		else if (*s == '%' && *(s+1) != c) n++;
		s++;
	}

	if (!n || (!n && z && x)) return 1;
	return 0;
}
