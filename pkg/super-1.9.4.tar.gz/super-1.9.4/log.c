#include "super.h"

void logenv(const char *env)
{
	envlinel += xsnprintf(envline+envlinel, sizeof(envline)-envlinel, "\"%s\",", env);
}

void vappendlogline(const char *f, va_list ap)
{
	loglinel += vsnprintf(logline+loglinel, sizeof(logline)-loglinel, f, ap);
}

void appendlogline(const char *f, ...)
{
	va_list ap;
	va_start(ap, f);
	vappendlogline(f, ap);
	va_end(ap);
}

void startlogline(void)
{
	loglinel = 0;
	*logline = 0;

#ifdef SYSLOG_SUPPORT
	if (isflag(suflags, S_SYSLOG)) {
		/* Time stamps will be prepended by syslog() */
		openlog(NAME, LOG_PID, LOG_AUTHPRIV);
	}
	else {
#endif
		if (isflag(suflags, S_LOGUTS)) appendlogline("%lu ", time(NULL));
		else appendlogline("%s ", date_now());
		appendlogline("%u ", ourpid);
#ifdef SYSLOG_SUPPORT
	}
#endif
}

int endlogline(int warn)
{
	int x;

#ifdef SYSLOG_SUPPORT
	if (isflag(suflags, S_SYSLOG)) {
		syslog(warn ? LOG_ALERT : LOG_NOTICE, "%s", logline);
		closelog();
		/* syslog() gives us no way to check that message is logged; always "success" */
		return 1;
	}
	else {
#endif
		logfile = fopen(logpath, "a");
		if (!logfile) return 0;
		fchmod(fileno(logfile), 0640); /* always update mode */

		x = fputs(logline, logfile);
		if (x == EOF) return 0;
		x = fputc('\n', logfile);
		if (x == EOF) return 0;
		x = fflush(logfile);
		if (x == -1 || x == EOF) return 0;
		memzero(logline, sizeof(logline));

		fclose(logfile);
		logfile = NULL;

		return 1;
#ifdef SYSLOG_SUPPORT
	}
#endif
}

void undolog(void)
{
	memzero(logline, sizeof(logline));
#ifdef SYSLOG_SUPPORT
	if (isflag(suflags, S_SYSLOG)) closelog();
	else {
#endif
		if (!logfile) return;
		fclose(logfile);
		logfile = NULL;
#ifdef SYSLOG_SUPPORT
	}
#endif
}
