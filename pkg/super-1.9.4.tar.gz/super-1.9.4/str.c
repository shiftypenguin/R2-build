#include "super.h"

char *s_strndup(const char *s, size_t n)
{
	size_t l = strnlen(s, n);
	char *d = nmalloc(l+1); /* gives zero memory */

	if (!d) return NULL;
	memcpy(d, s, l);

	return d;
}

void s_sstrrep(char *s, size_t l, const char *f, const char *t)
{
	size_t fl = strlen(f), tl = strlen(t);
	char *x = s;

	if (tl > fl) return;

	l = strnlen(x, l);
	while ((s = strstr(s, f))) {
		memmove(s, t, tl);
		memmove(s+tl, s+fl, strnlen(s+fl, l));
		l -= fl; l += tl;
	}
	*(x+l) = 0;
}

void s_strrep(char *s, const char *f, const char *t)
{
	s_sstrrep(s, strnlen(s, _ALLOC_MAX), f, t);
}

void char_to_nul(char *s, size_t l, int c)
{
	while (*s && l) { if (*s == c) { *s = 0; break; } s++; l--; }
}

int iscomment(const char *s)
{
	if (!*s
	|| *s == '#'
	|| *s == '\n'
	|| (*s == '\r' && *(s+1) == '\n')
	|| *s == ';'
	|| (*s == '/' && *(s+1) == '/')) return 1;
	return 0;
}
int xsnprintf(char *s, size_t n, const char *fmt, ...)
{
	int r;
	va_list ap;

	va_start(ap, fmt);

	memzero(s, n);

	r = vsnprintf(s, n, fmt, ap);

	va_end(ap);

	return r;
}

size_t xstrlcpy(char *d, const char *s, size_t n)
{
	/*
	 * Always tell your children that type casting in security software is harmful.
	 * And they will not listen to you, obviously. They will learn on their own mistakes.
	 * Then do not restrict their self learning then. They're in different execution domain already.
	 * XXX HELLO THEO! XXX
	 */
	return (size_t)xsnprintf(d, n, "%s", s);
}

/* what an abusive declaration fgets has */
int xfgets(char *s, size_t n, FILE *f)
{
	/* super does not read such many characters anyway */
	if (n >= _XSALLOC_MAX) return 0;

	/* safety first! */
	memzero(s, n);

	if (fgets(s, (int)n, f) == s) {
		newline_to_nul(s, n);
		return 1;
	}

	return 0;
}

char *xastrncat(char **d, const char *s, size_t n)
{
	size_t l = strlen(*d);

	*d = xrealloc(*d, l+n+1);
	xstrlcpy(*d+l, s, n);

	return *d;
}

char *xstrdup(const char *s)
{
	char *r = s_strndup(s, _ALLOC_MAX);
	if (!r) {
		errstr = NULL;
		xerror("xstrdup");
		return NULL;
	}
	else return r;
}
