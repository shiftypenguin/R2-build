#include "super.h"

int issuper(void)
{
#ifdef HAVE_SYS_ISSETUGID
	if (!issetugid()) return 0; /* On really safe systems with -DHAVE_SYS_ISSETUGID */
#endif
	return !!(srcuid == 0);
}

int cfg_permission(const struct stat *st)
{
	if (st->st_uid != 0 || st->st_gid != 0) return 0;
	if (isflag(st->st_mode, S_IXUSR)) return 0; /* --x------ */
	if (isflag(st->st_mode, S_IRGRP)) return 0; /* ----w---- */
	if (isflag(st->st_mode, S_IWGRP)) return 0; /* ----w---- */
	if (isflag(st->st_mode, S_IXGRP)) return 0; /* -----x--- */
	if (isflag(st->st_mode, S_IROTH)) return 0; /* ------r-- */
	if (isflag(st->st_mode, S_IWOTH)) return 0; /* -------w- */
	if (isflag(st->st_mode, S_IXOTH)) return 0; /* --------x */
				       /* Not allowed: --xrwxrwx */
					/* Allowed:    rw------- */

	return 1;
}

void blame(const char *f, ...)
{
	va_list ap;
	va_start(ap, f);
	appendlogline(": ");
	vappendlogline(f, ap);
	va_end(ap);

	if (!isflag(suflags, S_LOG) && !isflag(suflags, S_LOGFAIL)) undolog();
	else {
		if (!endlogline(1)) xerror("endlogline");
	}
	close_conf();

	if (!noblame) {
	/* This is where I insult invoker */
		blocksleep(1); /* Never unblock */
		usleep(delay);
		if (strnlen(denymsg, sizeof(denymsg)-1)) {
			if (if_quiet && !strncmp(denymsg, DENY_MSG, _ALLOC_MAX)) goto _out;

			fputs(denymsg, stderr);
			fputc('\n', stderr);
			fflush(stderr);
		}
	}

_out:	xexit(1);
}

/*
 * The most stupid and portable way
 * of closing opened fds.
 */

void s_closefrom(int fd)
{
	int x, max = (maxfd == -1) ? sysconf(_SC_OPEN_MAX) : maxfd;

	for (x = fd; x < max; x++) close(x);
}

int runaway(void)
{
	gid_t t = 0;

	if (setreuid(0, 0) == -1) goto _err;
	if (setregid(0, 0) == -1) goto _err;
	setgroups(1, &t);

	return 1;

_err:
	return 0;
}

/*
 * This one probably requires more attention, but
 * that's probably will make code unportable.
 */

void ttydetach(void)
{
	int fd;

	if (setpgid(0, 0) == -1) xerror("ttydetach");
	if ((fd = open("/dev/tty", O_RDWR)) != -1) {
		ioctl(fd, TIOCNOTTY, NULL);
		close(fd);
	}
}

void blocksleep(int block)
{
	static int blocked;

	if (block && blocked) return;

	s_sigblock(SIGTERM, block);
	s_sigblock(SIGHUP, block);
	s_sigblock(SIGINT, block);
	s_sigblock(SIGQUIT, block);
	s_sigblock(SIGTSTP, block);
	s_sigblock(SIGPIPE, block);
	s_sigblock(SIGABRT, block);
	s_sigblock(SIGALRM, block);

	if (block) blocked = 1;
	else blocked = 0;
}

void warnusr(void)
{
	int fd;
	char c, n;

	if (!cmdline) return;

	if ((fd = open("/dev/tty", O_RDONLY|O_NOCTTY)) < 0) fd = 0;

	fprintf(stderr, "You are about to execute this:\n");
	fprintf(stderr, "`%s`,\n", cmdline);
	fprintf(stderr, "as %s(%u),%s(%u):%s(%u),%s(%u)[%s]\n",
			dstusr, dstuid, dsteusr, dsteuid,
			dstgrp, dstgid, dstegrp, dstegid, dstgrps);
	fprintf(stderr, "Continue? ");
	fflush(stderr);

	read(fd, &c, 1);
	read(fd, &n, 1);
	if (fd > 2) close(fd);

	if ((c == 'Y' || c == 'y') && n == '\n') return;
	else {
		fprintf(stderr, "Aborted by user.\n");
		noblame = 1;
		blame("aborted by user");
	}
}
