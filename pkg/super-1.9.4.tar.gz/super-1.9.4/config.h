/* super internal defines */

/* location of master config file */
#define PATH_SUPERCONF "/etc/super.conf"
/* where to write master log file */
#define PATH_SUPERLOG "/var/log/super.log"
/* directory to put empty lock files into, to prevent brute force */
#define PATH_LOCKS "/var/run/" /* include ending '/' */
/* ending suffix of lock file name, here: ".super" */
#define PATH_LOCKS_SUF "." NAME
/* default shell which is started when login with -I */
#define DEFAULT_SHELL "/bin/sh"
/* safe path: only binaries from these directories are run when only name is told */
#define SAFE_PATH "/bin:/sbin:/usr/bin:/usr/sbin"

/* portability */

/* Do you have shadow support in your libc or elsewhere? */
#define SHADOW_SUPPORT
/* Do you have syslog support? You probably do. */
#define SYSLOG_SUPPORT
/* Your system is classic Linux/glibc? */
#define HAVE_SYS_CRYPT
/* ... If not (BSD), #undef this one. */
#define HAVE_CRYPT_H
/* You build for OS X with it's insane setgroups(2) */
#undef GROUPSLIMIT
/* You build for OpenBSD with true issetugid(2) syscall */
#undef HAVE_SYS_ISSETUGID
/* Your system does not define endian.h or htole64 macro */
#undef IS_LITTLE_ENDIAN
/* Never call fork(2) */
#undef NOFORK
/* Never reset resource limits to safer values, trust invoker fully */
#undef NORESETRLIMITS
/* #define this if your system is SaneLinux (http://lynxlynx.ru/cgit/cgit.cgi/sanelinux/). */
#undef ON_SANELINUX
