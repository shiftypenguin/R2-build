#include "super.h"

static char path[PATH_MAX];

/* @exit call */
void __wipevars_dir(void)
{
	memzero(path, sizeof(path));
}

int xchdir(const char *s)
{
	if (chdir(s) == -1) {
		s_error(s);
		if (chdir(defroot) == -1) {
			s_error(s);
			return -1;
		}
	}
	return 0;
}

char *xgetcwd(void)
{
	memzero(path, sizeof(path));

	if (!getcwd(path, sizeof(path))) xsnprintf(path, sizeof(path), "%s", strerror(errno));

	return xstrdup(path);
}

