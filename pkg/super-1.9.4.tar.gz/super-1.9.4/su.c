#include "super.h"

/*
 * Basic su(1) emulation.
 *
 * WARNING: This code MUST NOT alter or otherwise call super(8) code in any way.
 * Only util functions are permitted (memory allocation, error exit etc.)
 * It must drop privileges as early as possible and then perform as a standalone program.
 * It must call super only by a loosely knowable path in filesystem via execl()
 * which is based on a installation prefix given at compile time and only.
 * SANELINUX introduces self executed path lookup syscall, so finding ourself in fs
 * will be much easier on such kernels, but making this real is still big TODO as of Dec2016.
 *
 * This modern su(1) supports old shell script and becomes a super builtin.
 * This su(1) supports -lmp, -c cmdline, -s shell and dash.
 *
 * This is purely user su(1), which does not deal with numbers at all, leaving them to super(8).
 *
 * This code maybe buggy, but not exploitable because it drops privileges.
 */

#ifdef ON_SANELINUX
/* Future sanelinux extensions */
#define PATH_SUPER getprogpath()
#else
#define PATH_SUPER PREFIX "/bin/" NAME
#endif

#define RES_SUSER 1
#define RES_SHELL 2

static char *su_shell;
static char *su_cmdline;
static int su_dologin, su_preserve;
static char *su_user, *su_group, *su_groups;

static void su_usage(void)
{
	printf("usage: su [-] [-lmp] [-c cmdline] [-s shell] [user] [group] [groups]\n");
	exit(1);
}

static char *ask_super(int w, const char *u)
{
	FILE *p;
	static char su_resret[256];
	size_t l;
	int r;

	memzero(su_resret, sizeof(su_resret));

	if (w == RES_SUSER) {
		snprintf(su_resret, sizeof(su_resret), "%s -c suser", PATH_SUPER);
	}
	else if (w == RES_SHELL && u) {
		snprintf(su_resret, sizeof(su_resret), "%s -u %s -c shell", PATH_SUPER, u);
	}
	else xerrexit_n("su", "ask_super(%u, %p)\n", w, u);

	p = popen(su_resret, "r");
	if (!p) return NULL;

	memzero(su_resret, sizeof(su_resret));
	l = fread(su_resret, 1, sizeof(su_resret), p); l--;
	su_resret[l] = 0;

	r = pclose(p);
	r = WEXITSTATUS(r);
	if (r) xerrexit_n("su", "super returned %d.", r);

	return xstrdup(su_resret);
}

static void do_login(const char *shell, const char *u, const char *g, const char *G)
{
	if (shell) { /* if super will deny you doing that then it's your fault! */
		if (u && !g && !G) execl(PATH_SUPER, NAME, "-u", u, "-A", "--", shell, NULL);
		else if (u && g && !G) execl(PATH_SUPER, NAME, "-u", u, "-g", g, "-A", "--", shell, NULL);
		else if (u && g && G) execl(PATH_SUPER, NAME, "-u", u, "-g", g, "-s", G, "-A", "--", shell, NULL);
	}
	else {
		if (u && !g && !G) execl(PATH_SUPER, NAME, "-u", u, "-l", NULL);
		else if (u && g && !G) execl(PATH_SUPER, NAME, "-u", u, "-g", g, "-l", NULL);
		else if (u && g && G) execl(PATH_SUPER, NAME, "-u", u, "-g", g, "-s", G, "-l", NULL);
	}
}

static void do_exec(const char *cmdline, const char *shell,
		    const char *u, const char *g, const char *G, int mp)
{
	char *P = "-E";

	if (mp) P = "-P";

	if (u && !g && !G)
		execl(PATH_SUPER, NAME, "-u", u, P, "--", shell, "-c", cmdline, NULL);
	else if (u && g && !G)
		execl(PATH_SUPER, NAME, "-u", u, "-g", g, P, "--", shell, "-c", cmdline, NULL);
	else if (u && g && G)
		execl(PATH_SUPER, NAME, "-u", u, "-g", g, "-s", G, P, "--", shell, "-c", cmdline, NULL);
	else su_usage();
}

/* really used only when called like "su -c id user group groups" -- to find out tail args. */
static char *argv_find_next(int argc, char *const *argv, const char *str, int offs, int noarg)
{
	int x;

	for (x = 0; argv[x]; x++) {
		if (!strcmp(argv[x], str) && argv[x+offs]) {
			if (noarg && argv[x+offs][0] == '-') return NULL;
			if (x+offs < argc) return argv[x+offs];
		}
	}

	return NULL;
}

int su_main(int argc, char **argv, uid_t srcuid, gid_t srcgid, int srcgsz, gid_t *srcgids)
{
	int c;
	char *s;

	/*
	 * su acts like an ordinary executable, but super's early main()
	 * resets limits to safe minimals - so restore them here again.
	 */
	restore_user_limits();
	/* drop privs as early as possible */
	if (setgroups(srcgsz, srcgids) == -1) xerror("su_setgroups");
	if (setregid(srcgid, srcgid) == -1) xerror("su_setregid");
	if (setreuid(srcuid, srcuid) == -1) xerror("su_setreuid");

	c = 1;
	optind = 1;
	while (c) {
		if (!argv[optind]) break;

		if (argv[optind][0] != '-') {
			switch (optind) {
				case 1: su_user = argv[optind]; break;
				case 2: su_group = argv[optind]; break;
				case 3: su_groups = argv[optind]; break;
				default: c = 0; break;
			}
			optind++;
		}
		else break;
	}

	opterr = 1;
	while ((c = getopt(argc, argv, "lmpc:s:")) != -1) {
		switch (c) {
			case 'l': su_dologin = 1; break;
			case 'm':
			case 'p': su_preserve = 1; break;
			case 'c': su_cmdline = optarg; break;
			case 's': su_shell = optarg; break;
			default: su_usage(); break;
		}
	}

	if (argv[optind] && !strcmp(argv[optind], "-")) {
		su_dologin = 1;
		optind++;
	}

	if (su_user) goto _su_grp;

	su_user = argv[optind];
	if (!su_user) {
		su_user = ask_super(RES_SUSER, NULL);
		goto _su_exec;
	}

_su_grp:
	if (su_user && !su_group) {
		s = argv_find_next(argc, argv, su_user, 1, 1);
		if (s) su_group = s;
	}
	if (su_user && su_group && !su_groups) {
		s = argv_find_next(argc, argv, su_user, 2, 1);
		if (s) su_groups = s;
	}

_su_exec:
	if (su_dologin) {
		/* if !su_shell, then do_login does super -l */
		do_login(su_shell, su_user, su_group, su_groups);
	}

	if (!su_shell) su_shell = ask_super(RES_SHELL, su_user);

	if (su_cmdline) {
		do_exec(su_cmdline, su_shell, su_user, su_group, su_groups, su_preserve);
	}

	do_exec(su_shell, su_shell, su_user, su_group, su_groups, su_preserve);

	return 127;
}
