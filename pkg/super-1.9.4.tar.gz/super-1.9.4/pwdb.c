#include "super.h"

uid_t uidbyname(const char *name)
{
	struct passwd *p;
	uid_t x;

	reseterr();
	x = usermap_getuid(name);
	if (x != NOUID) return x;
	if (isnum(name))
		return (uid_t)atoi(name);
	p = getpwnam(name);
	if (p) return p->pw_uid;
	else {
		seterr("No such user");
		return NOUID;
	}
}

gid_t gidbyuid(uid_t uid)
{
	struct passwd *p;
	gid_t x;

	reseterr();
	x = usermap_getgidbyuid(uid);
	if (x != NOGID) return x;
	p = getpwuid(uid);
	if (p) return p->pw_gid;
	else {
		seterr("No such uid");
		return NOGID;
	}
}

gid_t gidbyname(const char *name)
{
	struct group *g;
	gid_t x;

	reseterr();
	x = usermap_getgid(name);
	if (x != NOGID) return x;
	if (isnum(name))
		return (gid_t)atoi(name);
	g = getgrnam(name);
	if (g) return g->gr_gid;
	else {
		seterr("No such group");
		return NOGID;
	}
}

int getugroups(const char *name, gid_t gr, gid_t *grps, int *ngrps)
{
	reseterr();
	if (isnum(name)) {
		struct passwd *p;
		p = getpwuid(atoi(name));
		if (p) name = p->pw_name;
		else seterr("No such uid");
	}
	return getgrouplist(name, gr, grps, ngrps);
}

char *shellbyname(const char *name)
{
	struct passwd *p;
	char *r;

	reseterr();
	r = usermap_getushell(name);
	if (r) return r;
	if (isnum(name)) {
		p = getpwuid(atoi(name));
		if (!p) goto _binsh;
	}
	else {
		p = getpwnam(name);
		if (!p) goto _binsh;
	}
	r = s_strndup(p->pw_shell, _ALLOC_MAX);
	if (!r) goto _binsh;
	return r;

_binsh:
	return defsh;
}

char *udirbyname(const char *name)
{
	struct passwd *p;
	char *r;

	reseterr();
	r = usermap_getudir(name);
	if (r) return r;
	if (isnum(name)) {
		p = getpwuid(atoi(name));
		if (!p) goto _root;
	}
	else {
		p = getpwnam(name);
		if (!p) goto _root;
	}
	r = s_strndup(p->pw_dir, _ALLOC_MAX);
	if (!r) goto _root;
	return r;

_root:
	return defroot;
}

char *namebyuid(uid_t uid)
{
	struct passwd *p;
	char *r;

	reseterr();
	r = usermap_getnamebyuid(uid);
	if (r) return r;
	p = getpwuid(uid);
	if (p) return xstrdup(p->pw_name);
	else {
		r = xmalloc(_SUID_MAX);
		xsnprintf(r, _SUID_MAX, "%u", uid);
		return r;
	}
}

char *namebygid(gid_t gid)
{
	struct group *g;

	reseterr();
	g = getgrgid(gid);
	if (g) return xstrdup(g->gr_name);
	else {
		char *r;

		r = xmalloc(_SUID_MAX);
		xsnprintf(r, _SUID_MAX, "%u", gid);
		return r;
	}
}

char *build_usergroups(int size, gid_t *list, int forid)
{
	int x;
	char *r, *R, *X;

	r = R = xmalloc(_ALLOC_MAX);
	for (x = 0; x < size; x++) {
		X = namebygid(*(list+x));
		if (forid) R += xsnprintf(R, _ALLOC_MAX-(R-r), (size-x > 1) ? "%u(%s)," : "%u(%s)", *(list+x), X);
		else R += xsnprintf(R, _ALLOC_MAX-(R-r), (size-x > 1) ? "%s," : "%s", X);
		xfree(X);
	}

	return r;
}

int match_groups(gid_t gid, int size, gid_t *list)
{
	int x;

	for (x = 0; x < size; x++) if (!*(list+x) || *(list+x) == gid) return 1;
	return 0;
}

int match_password(const char *user, const char *secret)
{
	const char *hash;
	struct passwd *pw;
#ifdef SHADOW_SUPPORT
	struct spwd *p;
#endif

	/* First do match with locally defined usermaps */
	hash = usermap_gethash(user);
	if (hash) {
		if (!strcmp(s_crypt(secret, hash), hash)) return 1;
	}

	/* Otherwise, ask system about user passwords */
	else {
#ifdef SHADOW_SUPPORT
		p = getspnam(user);
		if (!p) goto _pw;
		hash = p->sp_pwdp;
		if (!hash) return 0;
		if (!strnlen(hash, _ALLOC_MAX) && !strnlen(secret, _ALLOC_MAX)) return 1;
		if (!strcmp(s_crypt(secret, hash), hash)) return 1;
_pw:
#endif
		pw = getpwnam(user);
		if (!pw) return 0;
		hash = pw->pw_passwd;
		if (!hash) return 0;
		if (!strnlen(hash, _ALLOC_MAX) && !strnlen(secret, _ALLOC_MAX)) return 1;
		if (!strcmp(s_crypt(secret, hash), hash)) return 1;
	}

	return 0;
}

int isnumgrps(const char *S)
{
	char *X = xstrdup(S), *s, *d;

	s = d = X;
	while ((s = strtok(d, ","))) {
		if (d) d = NULL;
		if (*s == '+' || *s == '-') s++;
		if (isnum(s)) goto _ret;
	}

	return 0;

_ret:
	xfree(X);
	return 1;
}
