#include "super.h"
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#ifndef IS_LITTLE_ENDIAN
#include <endian.h>
#else
#define htole64(x) (x)
#endif

#define _n _s

#define SALTLEN 16
#define DATALEN 48
#define OFFSET 11
#define PASSES 22005

#define SLENMAX 32
#define DLENMAX 90
#define CLEN (DLENMAX + SLENMAX + 4 + 1)
#define _PFX "$U$"
#define TUNECONF "/etc/skcrypt.conf"

unsigned int saltlen = SALTLEN;
unsigned int datalen = DATALEN;
unsigned int offset = OFFSET;
unsigned int passes = PASSES;
char localid[64] = {0};
int noskconf = 0;

typedef struct {
	uint64_t K[17];
	uint64_t T[3];
} tf1024_ctx;

#define THREEFISH_PARITY 0x1bd11bdaa9fc1a22ULL

static void tfs1024_init(tf1024_ctx *ctx)
{
	size_t i;

	ctx->K[_n(ctx->K) - 1] = THREEFISH_PARITY;
	for (i = 0; i < _n(ctx->K) - 1; i++)
		ctx->K[_n(ctx->K)-1] ^= ctx->K[i];

	ctx->T[2] = ctx->T[0] ^ ctx->T[1];
}

static const uint8_t sched1024[] = {
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
	0, 9, 2, 13, 6, 11, 4, 15, 10, 7, 12, 3, 14, 5, 8, 1,
	0, 7, 2, 5, 4, 3, 6, 1, 12, 15, 14, 13, 8, 11, 10, 9,
	0, 15, 2, 11, 6, 13, 4, 9, 14, 1, 8, 5, 10, 3, 12, 7
};

static const uint8_t rot1024[] = {
	24, 13, 8, 47, 8, 17, 22, 37, 38, 19, 10, 55, 49, 18, 23, 52,
	33, 4, 51, 13, 34, 41, 59, 17, 5, 20, 48, 41, 47, 28, 16, 25,
	41, 9, 37, 31, 12, 47, 44, 30, 16, 34, 56, 51, 4, 53, 42, 41,
	31, 44, 47, 46, 19, 42, 44, 25, 9, 48, 35, 52, 23, 31, 37, 20
};

static void tf1024_encrypt_blk(const tf1024_ctx *ctx, const uint64_t *in, uint64_t *out)
{
	size_t i, r, s, a, b;

	for (i = 0; i < 16; i++)
		out[i] = ctx->K[i] + in[i];
	out[13] += ctx->T[0];
	out[14] += ctx->T[1];

	for (r = 1, s = 0; r <= 20; r++, s ^= _n(rot1024)/2) {
		for (i = 0; i < _n(sched1024)/2; i++) {
			a = sched1024[i*2];
			b = sched1024[i*2+1];

			out[a] += out[b];
			out[b] = (out[b] << rot1024[i+s]) | (out[b] >> (64 - rot1024[i+s]));
			out[b] ^= out[a];
		}

		for (i = 0; i < 16; i++)
			out[i] += ctx->K[(r+i) % _n(ctx->K)];
		out[13] += ctx->T[r % _n(ctx->T)];
		out[14] += ctx->T[(r+1) % _n(ctx->T)];
		out[15] += r;
	}
}

#define SKEIN_VERSION 1
#define SKEIN_ID 0x33414853

#define SKEIN_BLOCK_CFG ((uint64_t)4 << 56)
#define SKEIN_BLOCK_MSG ((uint64_t)48 << 56)
#define SKEIN_BLOCK_OUT ((uint64_t)63 << 56)

#define SKEIN_FLAG_FIRST ((uint64_t)1 << 62)
#define SKEIN_FLAG_LAST ((uint64_t)1 << 63)

typedef struct {
	tf1024_ctx tf;
	size_t hl, bl;
	uint8_t B[128];
} sk1024_ctx;

static void skput64lsb(uint8_t *dst, const uint64_t *src, size_t l)
{
	size_t n;

	for (n = 0; n < l; n++)
		dst[n] = (uint8_t)(src[n>>3] >> (8*(n&7)));
}

static void skget64lsb(uint64_t *dst, const uint8_t *src, size_t l)
{
	size_t n;

	for (n = 0; n<8*l; n += 8)
		dst[n/8] = (((uint64_t) src[n])) +
			(((uint64_t)src[n+1]) << 8) +
			(((uint64_t)src[n+2]) << 16) +
			(((uint64_t)src[n+3]) << 24) +
			(((uint64_t)src[n+4]) << 32) +
			(((uint64_t)src[n+5]) << 40) +
			(((uint64_t)src[n+6]) << 48) +
			(((uint64_t)src[n+7]) << 56);
}

static void sk1024_process_blk(sk1024_ctx *ctx, const uint8_t *in, size_t bnum, size_t l)
{
	uint64_t x[16], y[16];
	size_t i;

	do {
		ctx->tf.T[0] += l;

		skget64lsb(x, in, _n(x));
		in += sizeof(x);

		tfs1024_init(&ctx->tf);
		tf1024_encrypt_blk(&ctx->tf, x, y);
		for (i = 0; i < 16; i++)
			ctx->tf.K[i] = y[i] ^ x[i];

		ctx->tf.T[1] &= ~SKEIN_FLAG_FIRST;
	} while (--bnum);
}

static void sk1024_init(sk1024_ctx *ctx, size_t hbits)
{
	uint64_t cfg[16];

	ctx->hl = hbits;
	ctx->bl = 0;

	memzero(cfg, sizeof(cfg));
	cfg[0] = htole64(((uint64_t) SKEIN_VERSION << 32) + SKEIN_ID);
	cfg[1] = htole64(hbits);

	ctx->tf.T[0] = 0;
	ctx->tf.T[1] = SKEIN_BLOCK_CFG | SKEIN_FLAG_FIRST | SKEIN_FLAG_LAST;

	memzero(ctx->tf.K, sizeof(ctx->tf.K));
	sk1024_process_blk(ctx, (uint8_t *)cfg, 1, 32);

	ctx->tf.T[0] = 0;
	ctx->tf.T[1] = SKEIN_BLOCK_MSG | SKEIN_FLAG_FIRST;
}

static void sk1024_update(sk1024_ctx *ctx, const void *msg, size_t l)
{
	const uint8_t *umsg = msg;
	size_t n;

	if (l + ctx->bl > 128) {
		if (ctx->bl) {
			n = 128 - ctx->bl;
			if (n) {
				memcpy(&ctx->B[ctx->bl], umsg, n);
				l -= n;
				umsg += n;
				ctx->bl += n;
			}
			sk1024_process_blk(ctx, ctx->B, 1, 128);
			ctx->bl = 0;
		}

		if (l > 128) {
			n = (l-1) / 128;
			sk1024_process_blk(ctx, umsg, n, 128);
			l -= n * 128;
			umsg += n * 128;
		}
	}

	if (l) {
		memcpy(&ctx->B[ctx->bl], umsg, l);
		ctx->bl += l;
	}
}

static void sk1024_final(sk1024_ctx *ctx, void *outhash)
{
	uint8_t *hash = outhash;
	uint64_t key[16];
	size_t i, b, n;

	if (ctx->bl < 128)
		memzero(ctx->B + ctx->bl, 128 - ctx->bl);
	ctx->tf.T[1] |= SKEIN_FLAG_LAST;
	sk1024_process_blk(ctx, ctx->B, 1, ctx->bl);

	b = (ctx->hl + 7) / 8;

	memzero(ctx->B, sizeof(ctx->B));
	memcpy(key, ctx->tf.K, sizeof(key));

	for (i = 0; i * 128 < b; i++) {
		((uint64_t *)ctx->B)[0] = htole64((uint64_t)i);
		ctx->tf.T[0] = 0;
		ctx->tf.T[1] = SKEIN_BLOCK_OUT | SKEIN_FLAG_FIRST | SKEIN_FLAG_LAST;
		ctx->bl = 0;

		sk1024_process_blk(ctx, ctx->B, 1, sizeof(uint64_t));
		n = b - i*128;
		if (n >= 128) n = 128;
		skput64lsb(hash+i*128, ctx->tf.K, n);
		memcpy(ctx->tf.K, key, sizeof(key));
	}
}

static void sk1024(const void *src, size_t slen, void *dst, size_t hbits)
{
	sk1024_ctx ctx; memzero(&ctx, sizeof(sk1024_ctx));

	sk1024_init(&ctx, hbits);
	sk1024_update(&ctx, src, slen);
	sk1024_final(&ctx, dst);

	memzero(&ctx, sizeof(sk1024_ctx));
}

static const char b64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void b64_encode(char *dst, const unsigned char *src, size_t length)
{
	unsigned char in[3] = {0};
	char *p = NULL;
	int i, len = 0;
	int j = 0;

	dst[0] = '\0'; p = dst;
	while (j < length) {
		len = 0;
		for (i=0; i<3; i++) {
			in[i] = (unsigned char) src[j];
			if (j < length) {
				len++; j++;
			}
			else in[i] = 0;
		}
		if (len) {
			p[0] = b64[in[0] >> 2];
			p[1] = b64[((in[0] & 0x03) << 4) | ((in[1] & 0xf0) >> 4)];
			p[2] = (unsigned char) (len > 1 ? b64[((in[1] & 0x0f) << 2) |
				((in[2] & 0xc0) >> 6)] : '=');
			p[3] = (unsigned char) (len > 2 ? b64[in[2] & 0x3f] : '=');
			p[4] = '\0';
			p += 4;
		}
	}
}

static void stripchr(char *s, const char *rem)
{
	const char *rst = rem;
	char *d = s;
	int add = 0;

	while (*s) {
		while (*rem) {
			if (*s != *rem) add = 1;
			else { add = 0; break; }
			rem++;
		}

		if (add) *d++ = *s;

		s++;
		rem = rst;
	}

	memzero(d, s-d);
}

static void juggle(const char *inp1, const char *inp2, const char *inp3, unsigned char *out)
{
	sk1024_ctx ctx; memzero(&ctx, sizeof(sk1024_ctx));
	int i;

	sk1024_init(&ctx, 1024);
	sk1024_update(&ctx, inp1, strnlen(inp1, DATALEN));
	sk1024_update(&ctx, inp2, strnlen(inp2, DATALEN));
	sk1024_update(&ctx, inp3, strnlen(inp3, DATALEN));
	sk1024_final(&ctx, out);

	for (i = 0; i < passes; i++) sk1024(out, 128, out, 1024);
}

static int readconfig(void)
{
	FILE *f;
	char buf[256];
	char *t, *n;
	struct stat st;

	memzero(buf, sizeof(buf));

	if (lstat(TUNECONF, &st) == -1) return 1;

	f = fopen(TUNECONF, "r");
	if (f) {
/*
		The config is:
		passes = PASSES
		offset = OFFSET
		localid = hello world foo bar
		slen = SALTLEN
		dlen = DATALEN
*/
		while (fgets(buf, 256, f) != NULL) {
			if (buf[0] == '\n' || buf[0] == '#') continue;
			buf[strnlen(buf, 256)-1] = '\0';
			t = strtok(buf, " = ");
			if (!t) continue;
			n = strtok(NULL, "=");
			if (!n) continue;
			if (n[0] == ' ') n++;

			if (!strcmp(t, "passes")) {
				passes = atoi(n);
				continue;
			}
			if (!strcmp(t, "offset")) {
				offset = atoi(n);
				continue;
			}
			if (!strcmp(t, "localid")) {
				strncpy(localid, n, 64);
				continue;
			}
			if (!strcmp(t, "slen")) {
				saltlen = atoi(n);
				continue;
			}
			if (!strcmp(t, "dlen")) {
				datalen = atoi(n);
				continue;
			}
		}
		fclose(f);

		if (passes == 0)		passes = PASSES;
		if (passes == UINT_MAX)		passes = 0;
		if (offset == 0)		offset = OFFSET;
		if (offset >= 64)		offset = 64;
		if (saltlen == 0)		saltlen = SALTLEN;
		if (saltlen == UINT_MAX)	saltlen = 0;
		if (saltlen >= SLENMAX)		saltlen = SLENMAX;
		if (datalen == 0)		datalen = DATALEN;
		if (datalen >= DLENMAX)		datalen = DLENMAX;
	}
	else return 1;

	return 0;
}

char *s_crypt_r(const char *clear, const char *salt, char *output)
{
	char buf[CLEN * 2] = {0}, buf2[CLEN * 2] = {0};
	unsigned char hashbytes[128] = {0};
	char slt[128] = {0};
	int slen = 0;
	char *p = output;

	if (!noskconf) readconfig();

	/* Process salt */
	if (salt[0] == _PFX[0] && salt[1] == _PFX[1] && salt[2] == _PFX[2]) {
		const char *s, *d;
		s = salt+3;
		d = strchr(s, _PFX[0]);
		if (!d) d = s;
		slen = (d-s) > saltlen ? saltlen : (d-s);
		strncpy(slt, s, slen);
	}
	else {
		*p = '*';
		goto _ret;
	}

	/* crypt and convert to base64 */
	juggle(clear, slt, localid, hashbytes);
	b64_encode(buf, hashbytes, sizeof(hashbytes));
	stripchr(buf, "./+=");
	memzero(hashbytes, sizeof(hashbytes));
	strncpy(buf2, buf+offset, datalen);
	memzero(buf, sizeof(buf));
	strncpy(buf, buf2, datalen);
	memzero(buf2, sizeof(buf2));

	/* Return result */
	snprintf(p, datalen+1 + saltlen + 4, _PFX"%s$%s", slt, buf);

	memzero(buf, sizeof(buf));
	memzero(slt, sizeof(slt));

_ret:
	return p;
}

char *s_crypt(const char *key, const char *salt)
{
	static char p[128];
	char *r;

	r = s_crypt_r(key, salt, p);
	if (*p == '*') r = xcrypt(key, salt);

	return r;
}

/* Our sane crypt() interface to system's crypt(). */
char *xcrypt(const char *key, const char *salt)
{
	char *r = NULL;

#ifdef HAVE_SYS_CRYPT
	r = crypt(key, salt);
#endif
/* Okay, following musl's behavior here because it's a wrapper for common crypt(). */
	if (!r) r = (*salt == '*') ? "x" : "*";
	return r;
}

