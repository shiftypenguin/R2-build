#include "super.h"

struct rlimitnames {
	int num;
	char shellname;
	const char *name;
};

#ifndef NORESETRLIMITS
static struct rlimit rlim_tmp;

/* save and reset critical ones which may affect super operation. */
struct prsvrlims {
#ifdef RLIMIT_DATA
	struct rlimit data;
#else
#warning REQUIRED rlimit type RLIMIT_DATA is not defined!
#endif
#ifdef RLIMIT_STACK
	struct rlimit stack;
#else
#warning REQUIRED rlimit type RLIMIT_STACK is not defined!
#endif
#ifdef RLIMIT_RSS
	struct rlimit rss;
#endif
#ifdef RLIMIT_AS
	struct rlimit as;
#endif
#ifdef RLIMIT_CORE
	struct rlimit core;
#else
#warning REQUIRED rlimit type RLIMIT_CORE is not defined!
#endif
#ifdef RLIMIT_FSIZE
	struct rlimit fsize;
#endif
#ifdef RLIMIT_NOFILE
	struct rlimit nofile;
#endif
#ifdef RLIMIT_NPROC
	struct rlimit nproc;
#endif
};

static struct prsvrlims prsv_rlims;
#endif

/* shell "ulimit" opt chars are taken from busybox ash... */
static const struct rlimitnames rlimits[] = {
#ifdef RLIMIT_CPU
	{RLIMIT_CPU, 't', _CPPNSTR(RLIMIT_CPU)},
#endif
#ifdef RLIMIT_FSIZE
	{RLIMIT_FSIZE, 'f', _CPPNSTR(RLIMIT_FSIZE)},
#endif
#ifdef RLIMIT_DATA
	{RLIMIT_DATA, 'd', _CPPNSTR(RLIMIT_DATA)},
#endif
#ifdef RLIMIT_STACK
	{RLIMIT_STACK, 's', _CPPNSTR(RLIMIT_STACK)},
#endif
#ifdef RLIMIT_CORE
	{RLIMIT_CORE, 'c', _CPPNSTR(RLIMIT_CORE)},
#endif
#ifdef RLIMIT_RSS
	{RLIMIT_RSS, 'm', _CPPNSTR(RLIMIT_RSS)},
#endif
#ifdef RLIMIT_NPROC
	{RLIMIT_NPROC, 'p', _CPPNSTR(RLIMIT_NPROC)},
#endif
#ifdef RLIMIT_NOFILE
	{RLIMIT_NOFILE, 'n', _CPPNSTR(RLIMIT_NOFILE)},
#endif
#ifdef RLIMIT_MEMLOCK
	{RLIMIT_MEMLOCK, 'l', _CPPNSTR(RLIMIT_MEMLOCK)},
#endif
#ifdef RLIMIT_AS
	{RLIMIT_AS, 'v', _CPPNSTR(RLIMIT_AS)},
#endif
#ifdef RLIMIT_LOCKS
	{RLIMIT_LOCKS, 'w', _CPPNSTR(RLIMIT_LOCKS)},
#endif
#ifdef RLIMIT_SIGPENDING /* not in ash */
	{RLIMIT_SIGPENDING, 'S', _CPPNSTR(RLIMIT_SIGPENDING)},
#endif
#ifdef RLIMIT_MSGQUEUE /* not in ash */
	{RLIMIT_MSGQUEUE, 'Q', _CPPNSTR(RLIMIT_MSGQUEUE)},
#endif
#ifdef RLIMIT_NICE
	{RLIMIT_NICE, 'e', _CPPNSTR(RLIMIT_NICE)},
#endif
#ifdef RLIMIT_RTPRIO
	{RLIMIT_RTPRIO, 'r', _CPPNSTR(RLIMIT_RTPRIO)},
#endif
};

static int numrlim(const char *name)
{
	int x;

	if (isnum(name)) return atoi(name);

	for (x = 0; x < _s(rlimits); x++) {
		if (*name == rlimits[x].shellname && !*(name+1)) return rlimits[x].num;
		else if (!strcmp(name, rlimits[x].name) || !strcmp(name, rlimits[x].name+7)) return rlimits[x].num;
	}

	return -1;
}

void addrlim(const char *rlimspec)
{
	int x;
	char **X = rlims;

	x = 0;
	while (*X && x < _s(rlims)) { X++; x++; }
	*X = xstrdup(rlimspec);
}

int setrlim(const char *rlimspec)
{
	char *tmp;
	char *s, *d;
	int res;
	struct rlimit r;

	r.rlim_cur = r.rlim_max = 0;

	tmp = xmalloc(_ALLOC_MAX);

	xstrlcpy(tmp, rlimspec, _ALLOC_MAX-1);
	s = tmp;
	d = strchr(s, ':');
	if (!d) goto _err;
	*d = 0;
	res = numrlim(s); s = d+1;
	if (res == -1) goto _err;
	d = strchr(s, ':');
	if (!d) goto _err;
	*d = 0;
	if (!strcmp(s, "-1")) r.rlim_cur = RLIM_INFINITY;
	else r.rlim_cur = (rlim_t)xpatol(s);
	s = d+1;
	if (!strcmp(s, "-1")) r.rlim_max = RLIM_INFINITY;
	else r.rlim_max = (rlim_t)xpatol(s);

	xfree(tmp);

	return setrlimit(res, &r);

_err:
	xerrexit("Invalid rlimspec specification '%s' (should be: nrlim:soft:hard)", rlimspec);
	return 1; /* never */
}

void setreslimits(void)
{
	int x;

	for (x = 0; rlims[x]; x++) {
		if (setrlim(rlims[x]) == -1) xerror("ulimit(%s)", rlims[x]);
	}
}

#ifndef NORESETRLIMITS
#define getprsvrlim(x, y) \
	do { if (getrlimit(x, &y) == -1) xerror("getprsvrlim for " #x " failed"); } while (0)

void preserve_user_limits(void)
{
#ifdef RLIMIT_STACK
	getprsvrlim(RLIMIT_STACK, prsv_rlims.stack);
#endif
#ifdef RLIMIT_DATA
	getprsvrlim(RLIMIT_DATA, prsv_rlims.data);
#endif
#ifdef RLIMIT_RSS
	getprsvrlim(RLIMIT_RSS, prsv_rlims.rss);
#endif
#ifdef RLIMIT_AS
	getprsvrlim(RLIMIT_AS, prsv_rlims.as);
#endif
#ifdef RLIMIT_FSIZE
	getprsvrlim(RLIMIT_FSIZE, prsv_rlims.fsize);
#endif
#ifdef RLIMIT_CORE
	getprsvrlim(RLIMIT_CORE, prsv_rlims.core);
#endif
#ifdef RLIMIT_NOFILE
	getprsvrlim(RLIMIT_NOFILE, prsv_rlims.nofile);
#endif
#ifdef RLIMIT_NPROC
	getprsvrlim(RLIMIT_NPROC, prsv_rlims.nproc);
#endif
}

#define resetrlim(x, s, h) \
	do { rlim_tmp.rlim_cur = s; rlim_tmp.rlim_max = h; \
	if (setrlimit(x, &rlim_tmp) == -1) xerror("resetrlim for " #x " failed"); } while (0)

#define setprsvrlim(x, y) \
	do { if (setrlimit(x, &y) == -1) xerror("setprsvrlim for " #x " failed"); } while (0)

void reset_user_limits(void)
{
#ifdef RLIMIT_STACK
	/* reset to some safe value */
	resetrlim(RLIMIT_STACK, 1024*8192, 1024*8192);
#endif
#ifdef RLIMIT_DATA
	resetrlim(RLIMIT_DATA, -1, -1);
#endif
#ifdef RLIMIT_RSS
	resetrlim(RLIMIT_RSS, -1, -1);
#endif
#ifdef RLIMIT_AS
	resetrlim(RLIMIT_AS, -1, -1);
#endif
#ifdef RLIMIT_FSIZE
	resetrlim(RLIMIT_FSIZE, -1, -1);
#endif
#ifdef RLIMIT_CORE
	/* do not dump cores even if OS permits us */
	resetrlim(RLIMIT_CORE, 0, 0);
#endif
#ifdef RLIMIT_NOFILE
	resetrlim(RLIMIT_NOFILE, 1024, 4096);
#endif
#ifdef RLIMIT_NPROC
	/* enough? */
	resetrlim(RLIMIT_NPROC, 64, 64);
#endif
}

void restore_user_limits(void)
{
#ifdef RLIMIT_STACK
	setprsvrlim(RLIMIT_STACK, prsv_rlims.stack);
#endif
#ifdef RLIMIT_DATA
	setprsvrlim(RLIMIT_DATA, prsv_rlims.data);
#endif
#ifdef RLIMIT_RSS
	setprsvrlim(RLIMIT_RSS, prsv_rlims.rss);
#endif
#ifdef RLIMIT_AS
	setprsvrlim(RLIMIT_AS, prsv_rlims.as);
#endif
#ifdef RLIMIT_FSIZE
	setprsvrlim(RLIMIT_FSIZE, prsv_rlims.fsize);
#endif
#ifdef RLIMIT_CORE
	setprsvrlim(RLIMIT_CORE, prsv_rlims.core);
#endif
#ifdef RLIMIT_NOFILE
	setprsvrlim(RLIMIT_NOFILE, prsv_rlims.nofile);
#endif
#ifdef RLIMIT_NPROC
	setprsvrlim(RLIMIT_NPROC, prsv_rlims.nproc);
#endif
}
#endif
