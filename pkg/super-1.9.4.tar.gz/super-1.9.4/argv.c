#include "super.h"

/*
 * Refine a single passed argument into multiple ones.
 * - Copy args before argv+idx,
 * - Break single arg into multiple ones further down,
 * - Copy remainings after it.
 * This one does not parses special strings, it just breaks
 * up anything which contains space.
 */
void refine_argv(int *argc, char ***argv, int idx)
{
	char **tpp, *s, *d;
	int x, xidx = idx;

	tpp = xmalloc(sizeof(char *));
	for (x = 0; x < xidx; x++) {
		tpp = xrealloc(tpp, sizeof(char *) * (x+2));
		tpp[x] = *(*(argv)+x);
	}

	s = d = *(*(argv)+xidx);
	while ((s = strtok(d, " "))) {
		if (d) d = NULL;

		tpp = xrealloc(tpp, sizeof(char *) * (x+2));
		tpp[x] = s;
		x++;
	}
	tpp[x] = NULL;

	xidx++;
	while (*(*(argv)+xidx)) {
		tpp = xrealloc(tpp, sizeof(char *) * (x+2));
		tpp[x] = *(*(argv)+xidx);
		x++; xidx++;
	}
	tpp[x] = NULL;

	*argc = x;
	*argv = tpp;
}
