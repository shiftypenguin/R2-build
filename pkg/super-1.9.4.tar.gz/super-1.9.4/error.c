#include "super.h"

void __wipevars_match(void);
void __wipevars_cmdline(void);
void __wipevars_conf(void);
void __wipevars_dir(void);

void wipevars(void)
{
	__wipevars_match();
	__wipevars_cmdline();
	__wipevars_conf();
	__wipevars_dir();
	memzero(super, sizeof(super));
	memzero(confline, sizeof(confline));
	memzero(logline, sizeof(logline));
	memzero(envline, sizeof(envline));
	memzero(binpath, sizeof(binpath));
#ifdef PATH_LOCKS
	unlockfile();
#endif
}

void xexit(int status)
{
	if (if_quiet) status = 0;

	wipevars();
	close_conf();
	exit(status);
}

void xerror(const char *f, ...)
{
	va_list ap;
	char *p;

	if (if_quiet) xexit(0);

	va_start(ap, f);

	fprintf(stderr, "%s: ", NAME);
	vfprintf(stderr, f, ap);
	if (errstr) p = errstr;
	else if (errno) p = strerror(errno);
	else p = "no error information";
	fprintf(stderr, ": %s\n", p);

	va_end(ap);

	xexit(2);
}

void s_error(const char *f, ...)
{
	va_list ap;
	char *p;

	if (if_quiet) return;

	va_start(ap, f);

	fprintf(stderr, "%s: ", NAME);
	vfprintf(stderr, f, ap);
	if (errstr) p = errstr;
	else if (errno) p = strerror(errno);
	else p = "no error information";
	fprintf(stderr, ": %s\n", p);

	va_end(ap);
}

static void __xerrexit(const char *progname, const char *f, va_list ap)
{
	if (if_quiet) xexit(0);

	fprintf(stderr, "%s: ", progname ? progname : NAME);
	vfprintf(stderr, f, ap);
	fprintf(stderr, "\n");

	va_end(ap);

	xexit(2);
}

void xerrexit(const char *f, ...)
{
	va_list ap;

	va_start(ap, f);
	__xerrexit(NULL, f, ap);
}

void xerrexit_n(const char *progname, const char *f, ...)
{
	va_list ap;

	va_start(ap, f);
	__xerrexit(progname, f, ap);
}

void seterr(const char *f, ...)
{
	va_list ap;
	char *tmp;

	va_start(ap, f);

	tmp = xmalloc(_ALLOC_MAX);

	vsnprintf(tmp, _ALLOC_MAX-1, f, ap);

	errstr = s_strndup(tmp, _ALLOC_MAX);
	errno = 0;

	xfree(tmp);

	va_end(ap);
}

void reseterr(void)
{
	xfree(errstr);
	errno = 0;
}
