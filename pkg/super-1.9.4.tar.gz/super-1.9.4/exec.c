#include "super.h"

int forkexecve(const char *path, char *const argv[], char *const envp[], pid_t *svpid)
{
#ifndef NOFORK
	pid_t pid;
#endif

	if (!*path) return -1;

#ifdef NOFORK
	return -1;
#else
	pid = fork();
	if (svpid) *svpid = pid;
	switch (pid) {
		case -1:
			return -1;
			break;
		case 0:
			clear_user_environ();
			execve(path, argv, envp);

			exit(127);
			break;
		default: {
			int x, y;

			x = y = -1;

			signal(SIGCHLD, SIG_DFL);

			if (waitpid(pid, &x, 0) == -1) return -1;
			if (WIFEXITED(x)) y = WEXITSTATUS(x);

			signal(SIGCHLD, &s_sighandler);

			if (y) return y;
		}
			break;
	}
#endif
	return 0;
}

int lhexecvp(const char *file, char *const argv[], int ve)
{
#ifndef NOFORK
	int pfd[2];
#endif

	if (!*file) return -1;

#ifndef NOFORK
	if (pipe(pfd) != 0) return -1;
	fcntl(pfd[0], F_SETFD, fcntl(pfd[0], F_GETFD) | FD_CLOEXEC);
	fcntl(pfd[1], F_SETFD, fcntl(pfd[1], F_GETFD) | FD_CLOEXEC);

	switch (fork()) {
		case -1:
			goto _fail;
			break;
		case 0:
			if (setsid() < 0) goto _fail;

			close(0);
			close(1);
			close(2);
			open("/dev/null", O_RDWR);
			open("/dev/null", O_RDWR);
			open("/dev/null", O_RDWR);
			close(pfd[0]);

			if (ve) execve(file, argv, environ);
			else execvp(file, argv);

			write(pfd[1], &errno, sizeof(errno));
			close(pfd[1]);
			exit(127);

			break;
		default: {
			int x = 0;

			close(pfd[1]);
			while (read(pfd[0], &x, sizeof(errno)) != -1)
				if (errno != EAGAIN && errno != EINTR) break;
			close(pfd[0]);

			if (x) {
				errno = x;
				return -1;
			}
		}
			break;
	}

	return 0;

_fail:
	close(pfd[0]);
	close(pfd[1]);
#else
	errno = ENOSYS;
#endif
	return -1;
}

/*
 * Our endpoint replacer: after all work is done,
 * and uids are changed, I (in a completely new environment)
 * can safely replace ourself with target program (if it exists)
 *
 * The only exception here is lhexecvp(), which returns.
 */

int execute(const char *p, char *const argv[], int ve)
{
	int r;

	if (isflag(optflags, SI_OPT_p))
		fprintf(stderr, "%s\n", cmdline);
	if (isflag(optflags, SI_OPT_v)) {
		fprintf(stderr, "Running `%s`,\n", cmdline);
		fprintf(stderr, "as %s(%u),%s(%u):%s(%u),%s(%u)[%s]\n",
				dstusr, dstuid, dsteusr, dsteuid,
				dstgrp, dstgid, dstegrp, dstegid, dstgrps);
	}

	if (isflag(optflags, SI_OPT_b)) {
		r = lhexecvp(p, argv, ve);
		s_sigblock(SIGCHLD, 1); /* Have I a chance to escape quicker
					 than spawned process exits?
					 Even if not, s_sighandler() will xexit() on CHLD */
	}
	else if (ve) r = execve(p, argv, environ);
	else r = execvp(p, argv);

	if (r) {
		xsnprintf(super, sizeof(super), "%s", p);
		fprintf(stderr, "%s: %s\n", basename(super), strerror(errno));
		return 127;
	}

	return r;
}
