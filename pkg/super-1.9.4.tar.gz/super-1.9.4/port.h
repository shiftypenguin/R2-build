#ifndef _PORT_H
#define _PORT_H

#ifndef _BSD_SOURCE
#define _BSD_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <pwd.h>
#include <grp.h>
#ifdef HAVE_CRYPT_H
#include <crypt.h>
#endif
#ifdef SHADOW_SUPPORT
#include <shadow.h>
#endif
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <libgen.h>
#include <signal.h>
#include <fnmatch.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#ifdef SYSLOG_SUPPORT
#include <syslog.h>
#endif

typedef void (*sighandler_t)(int);

#ifndef LOG_AUTHPRIV
#define LOG_AUTHPRIV LOG_AUTH
#endif

#endif /* _PORT_H */
