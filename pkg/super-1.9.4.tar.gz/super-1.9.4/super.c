/*
 *	super: authenticator for Unix systems.
 */

#include "super.h"

static int x, c;
static char *s, *d;
static char *argv0, *loginshell, *dstusrshell, *dstusrdir;
static char **tpp;
static size_t n;
static int pfd, prio;
static int usage_long_req; /* A help text was requested. */
static char *c_opt; int pui_flags;
static char *hashbang;

static void super_askpass(void)
{
	if (isflag(suflags, S_PW)) {
		if (isflag(optflags, SI_OPT_n)) blame("password required");

		memzero(super, sizeof(super));
		if (isflag(optflags, SI_OPT_F)) {
			if (!fdgetstring(pfd, super, sizeof(super)-1))
				blame("wrong password fd %d", pfd);
		}
		else {
			if (isflag(suflags, S_DSTPW)) s = dstusr;
			else if (isflag(suflags, S_SUPW)) s = suusr;
			else s = srcusr;
			getpasswd(super, sizeof(super)-1, prompt, s);
		}
		blocksleep(1); /* early protect hash calculation */
		if (linepw) { /* pw=$U$salt$hash */
			if (strcmp(s_crypt(super, linepw), linepw) != 0)
				blame("wrong line password");
		}
		else if (isflag(suflags, S_DSTPW)) { /* destination user password? */
			if (!match_password(dstusr, super))
				blame("wrong password for %s", dstusr);
		}
		else if (isflag(suflags, S_SUPW)) { /* superuser password? */
			if (!match_password(suusr, super))
				blame("wrong superuser password");
		}
		else { /* No, invoker user password. */
			if (!match_password(srcusr, super))
				blame("wrong password");
		}
		memzero(super, sizeof(super));
	}

	blocksleep(0);
}

int main(int argc, char **argv)
{
#ifndef NORESETRLIMITS
	/* save current user limits before ANY code runs */
	preserve_user_limits();
	reset_user_limits();
#endif

	ourpid = getpid();
	parentpid = getppid();
#ifdef ON_SANELINUX
	progname = basename(getprogpath());
#else
	if (*argv) progname = basename(*argv);
#endif
	else progname = NAME;

	opterr = 0;
	errstr = NULL;

	if (isatty(0)) tcgetattr(0, &saneterm);

/* Get info about asking user */
	srcuid = getuid();
	srceuid = geteuid();
	srcgid = getgid();
	srcegid = getegid();
	srcgsz = _s(srcgids);
	srcgsz = getgroups(srcgsz, srcgids);

	if (!strcmp(progname, "su")) return su_main(argc, argv, srcuid, srcgid, srcgsz, srcgids);

/* |--^,--^,--^,--^,-- invoker - super border line --^,--^,--^,--^,--^,--^,--^,--^,--^,--^,--^,--^,--| */

/*
 * Raise any privilege to maximum:
 * don't let invoker to kill us without leaving a note in log
 * blame for every mistake
 * parse opts in protected environment
 */
#ifdef HAVE_SYS_ISSETUGID
	if (!issetugid()) xerrexit("%s is not marked as setuid executable", NAME);
#endif
	if (!runaway()) xerror("runaway");
/* Ignore any signals at this point, I do not want garbage in the logs */
	for (x = 1; x < NSIG; x++) signal(x, SIG_IGN);

#ifndef NORESETRLIMITS
	/* do that again */
	reset_user_limits();
#endif

	dstuid = dsteuid = NOUID;
	dstgid = dstegid = *dstgids = NOGID;

	suusr = namebyuid(DEF_ID);
	srcusr = namebyuid(srcuid);
	srceusr = namebyuid(srceuid);
	srcgrp = namebygid(srcgid);
	srcegrp = namebygid(srcegid);
	srcgrps = build_usergroups(srcgsz, srcgids, 0);

/* Open our configuration */
	if (!open_conf()) if (!issuper()) xerror(PATH_SUPERCONF);
/*
 * So I need to do that early, because of extended virtual user format
 * THIS can affect REAL user information, but only when extended %user is used!
 */
	readin_usermaps();
	init_keep_vars();

/* Support setuid scripts and others who pass all args as single argv cell */
	if (argc >= 3 && strchr(*(argv+1), ' ')) {
		hashbang = xstrdup(*(argv+1));
		refine_argv(&argc, &argv, 1);
	}

/* remaining getopt chars: */
/* 'ijkmoqwyz' */
/* 'JKNOWYZ' */
	optind = 1;
	while ((c = getopt(argc, argv, "u:U:g:G:s:S:e:Ec:C:a:AbBfF:hIlL:M:nPQ:rR:d:DtTHpvVxX")) != -1) {
		switch (c) {
			case 'b':
				setflag(&optflags, SI_OPT_b);
				break;
			case 'B':
				setflag(&optflags, SI_OPT_B);
				break;
			case 'f':
				if (!issuper()) xerrexit("Only superuser can do this.");
				close_conf();
				break;
			case 'F':
				setflag(&optflags, SI_OPT_F);
				if (optr_isnum(optarg)) pfd = atoi(optarg);
				break;
			case 'C':
				setflag(&optflags, SI_OPT_C);
				minfd = atoi(optarg);
				break;
			case 'c':
				c_opt = optarg;
				break;
			case 'u':
				setflag(&pui_flags, PUI_OPT_u);
				dstusr = optarg;
				dstuid = uidbyname(dstusr);
				if (dstuid == NOUID) xerror("uidbyname(%s)", dstusr);
				dstgid = gidbyuid(dstuid);
				if (dstgid == NOGID) dstgid = (gid_t)dstuid;
				break;
			case 'U':
				dsteusr = optarg;
				dsteuid = uidbyname(dsteusr);
				if (dsteuid == NOUID) xerror("uidbyname(%s)", dsteusr);
				break;
			case 'g':
				setflag(&pui_flags, PUI_OPT_g);
				dstgrp = optarg;
				dstgid = gidbyname(dstgrp);
				if (dstgid == NOGID) xerror("gidbyname(%s)", dstgrp);
				break;
			case 'G':
				dstegrp = optarg;
				dstegid = gidbyname(dstegrp);
				if (dstegid == NOGID) xerror("gidbyname(%s)", dstegrp);
				break;
			case 's':
				if (dstgrps) xerrexit("can't mix -S and -s");
				dstgrps = optarg;
				if (strchr(dstgrps, '+') || strchr(dstgrps, '-')) xerrexit("+- is not allowed with -s");
				xsnprintf(super, sizeof(super), "%s", optarg);
				s = d = super;
				while ((s = strtok(d, ","))) {
					if (d) d = NULL;
					tmpgid = gidbyname(s);
					if (tmpgid == NOGID) xerror("gidbyname(%s)", s);
					dstgids[dstgsz] = tmpgid; dstgsz++;
				}
				break;
			case 'S':
				setflag(&optflags, SI_OPT_S);
				if (dstgrps) xerrexit("can't mix -s and -S");
				dstgrps = optarg;
				xsnprintf(super, sizeof(super), "%s", optarg);
				if (!dstusr) {
					if (isflag(optflags, SI_OPT_x)) {
						if (dstuid == NOUID) dstuid = srcuid;
						if (dstgid == NOGID) dstgid = srcgid;
					}
					else {
						if (dstuid == NOUID) dstuid = DEF_ID;
						if (dstgid == NOGID) dstgid = DEF_ID;
					}
					dstusr = namebyuid(dstuid);
				}
				tmpgsz = _s(tmpgids);
				if (getugroups(dstusr, dstgid, tmpgids, &tmpgsz) == -1) xerror("getugroups(%s, %u, <>)", dstusr, dstgid);
				s = d = super;
				while ((s = strtok(d, ","))) {
					if (d) d = NULL;
					if (*s == '+') {
						tmpgid = gidbyname(s+1);
						if (tmpgid == NOGID) xerror("gidbyname(%s)", s+1);
						tmpgids[tmpgsz] = tmpgid; tmpgsz++;
					}
					else if (*s == '-') {
						tmpgid = gidbyname(s+1);
						if (tmpgid == NOGID) xerror("gidbyname(%s)", s+1);
						for (x = 0; x < tmpgsz && x < NGIDS; x++)
							if (tmpgid == tmpgids[x]) tmpgids[x] = NOGID;
					}
					else if (issuper() && (*s != '+' && *s != '-')) { 
						tmpgid = gidbyname(s);
						if (tmpgid == NOGID) xerror("gidbyname(%s)", s);
						tmpgids[tmpgsz] = tmpgid; tmpgsz++;
					}
					else xerrexit("syntax for -S: +gid,+group,-gid,...");
				}
				for (x = 0, dstgsz = 0; x < tmpgsz && x < NGIDS; x++) {
					if (tmpgids[x] != NOGID) {
						dstgids[dstgsz] = tmpgids[x];
						dstgsz++;
					}
				}
				break;
			case 't':
				dsteuid = DEF_ID;
				dsteusr = namebyuid(dsteuid);
				break;
			case 'T':
				dstegid = DEF_ID;
				dstegrp = namebygid(dstegid);
				break;
			case 'a':
				setflag(&optflags, SI_OPT_a);
				argv0 = optarg;
				break;
			case 'A':
				setflag(&optflags, SI_OPT_A);
				break;
			case 'P':
				setflag(&optflags, SI_OPT_P);
				break;
			case 'I':
			case 'l':
				setflag(&optflags, SI_OPT_LOGIN);
				if (c == 'I') setflag(&optflags, SI_OPT_I);
				break;
			case 'L':
				setflag(&optflags, SI_OPT_L);
				addrlim(optarg);
				break;
			case 'Q':
				setflag(&optflags, SI_OPT_Q);
				if (optr_isnum(optarg)) prio = atoi(optarg);
				break;
			case 'e':
				setflag(&optflags, SI_OPT_e);
				logenv(optarg);
				if (strchr(optarg, '=')) keep_envvar(optarg);
				else drop_envvar(optarg);
				break;
			case 'E':
				setflag(&optflags, SI_OPT_E);
				break;
			case 'D':
				setflag(&optflags, SI_OPT_dD);
				break;
			case 'd':
				setflag(&optflags, SI_OPT_dD);
				dstusrdir = optarg;
				break;
			case 'n':
				setflag(&optflags, SI_OPT_n);
				break;
			case 'r':
				setflag(&optflags, SI_OPT_r);
				break;
			case 'R':
				chrootdir = optarg;
				break;
			case 'p':
				setflag(&optflags, SI_OPT_p);
				break;
			case 'H':
				if (!issuper()) xerrexit("Only superuser can do this.");
				d = argv[optind];
				if (d && !strncmp(d, "s=", 2))
					s = d + 2;
				else
					s = mksalt();
_again:				getpasswd(super, (sizeof(super)/2)-1, "Password:");
				getpasswd(super+sizeof(super)/2, (sizeof(super)/2)-1, "Again:");
				if (!strncmp(super, super+(sizeof(super)/2), (sizeof(super)/2)-1)) {
					printf("%s\n", s_crypt(super, s));
				}
				else {
					fprintf(stderr, "Passwords are not same!\n");
					goto _again;
				}
				memzero(super, sizeof(super));
				xexit(0);
				break;
			case 'M':
				if (!issuper()) xerrexit("Only superuser can do this.");
				s = optarg;
				d = argv[optind];
				if (!d) {
					usage_long_req = 1;
					break;
				}
				printf("fnmatch(\"%s\", \"%s\") = %d\n",
					s, d, fnmatch(s, d, 0));
				xexit(0);
				break;
			case 'v':
				setflag(&optflags, SI_OPT_v);
				break;
			case 'V':
				opt_V_cnt++;
				if (opt_V_cnt > 2) opt_V_cnt = 2;
				break;
			case 'x':
				setflag(&optflags, SI_OPT_x);
				opt_x_cnt++;
				if (opt_x_cnt > 2) opt_x_cnt = 2;
				break;
			case 'X':
				setflag(&optflags, SI_OPT_x);
				setflag(&optflags, SI_OPT_X);
				break;
			case 'h':
			default: usage_long_req = 1; break;
		}
	}

	noptflags = optflags;
	if (!readin_defaults())	if (!issuper()) xerror("readin_defaults(%s)", PATH_SUPERCONF);

	if (usage_long_req) usage_long();
	if (opt_V_cnt) show_version();

	if (!*(argv+optind) && !isflag(optflags, SI_OPT_LOGIN) && !c_opt) usage();
	if (!isflag(optflags, SI_OPT_LOGIN)) cmdline = build_cmdline(argc-optind, argv+optind, 0);
	cwd = xgetcwd();
	tty_name = xttyname(0);
	logargv = build_cmdline(argc, argv, 1);
	logargvaudit = build_protected_cmdline(argc, argv);
	tpp = environ;
	for (x = 0; tpp[x]; x++);
	origenv = build_protected_cmdline(x, tpp);

	if (isflag(optflags, SI_OPT_x)) {
		if (dstuid == NOUID) dstuid = srcuid;
		if (dstgid == NOGID) dstgid = srcgid;
		if (opt_x_cnt == 2) {
			for (dstgsz = 0; dstgsz < srcgsz; dstgsz++) dstgids[dstgsz] = srcgids[dstgsz];
			dstgrps = build_usergroups(dstgsz, dstgids, 0);
		}
	}
	else {
		if (dstuid == NOUID) dstuid = DEF_ID;
		if (dstgid == NOGID) dstgid = DEF_ID;
	}
	if (isflag(optflags, SI_OPT_X)) {
		if (dstgids[0] == NOGID) {
			dstgids[0] = dstgid;
			dstgsz = 1;
			dstgrps = build_usergroups(dstgsz, dstgids, 0);
		}
	}
	if (dsteuid == NOUID) dsteuid = dstuid;
	if (dstegid == NOGID) dstegid = dstgid;

	if (!dstusr) dstusr = namebyuid(dstuid);
	if (!dsteusr) dsteusr = dstusr;
	if (!dstgrp) dstgrp = namebygid(dstgid);
	if (!dstgrp) dstgrp = dstusr;
	if (!dstegrp) dstegrp = dstgrp;
	if (!dstgrps) {
		dstgsz = _s(dstgids);
		if (getugroups(dstusr, dstgid, dstgids, &dstgsz) == -1) xerror("getugroups(%s, %u, <>)", dstusr, dstgid);
		dstgrps = build_usergroups(dstgsz, dstgids, 0);
	}
	if (!dstusrdir) dstusrdir = udirbyname(dstusr);
	dstusrshell = shellbyname(dstusr);

	if (isflag(optflags, SI_OPT_LOGIN)) {
		if (isflag(optflags, SI_OPT_I)) cmdline = xstrdup(defsh);
		else cmdline = xstrdup(dstusrshell);
	}

	if (c_opt) print_uidinfos(c_opt, pui_flags);

/* Start logging, read our initial configuration, if user is not super */
	if (issuper()) goto _bypass;
	else {
/* -------------- LOGGING START ------------- */
		startlogline();
	
		/* Okay to check tty for stdin; on every Unix stdin always zero. Same goes for S_TTY flag. */
		appendlogline("%s:%s[%s] %s,%s:%s,%s[%s", srcusr, srcgrp, srcgrps,
			dstusr, dsteusr, dstgrp, dstegrp, dstgrps);
		if (isflag(optflags, SI_OPT_S))
			appendlogline(":%s] ", build_usergroups(dstgsz, dstgids, 0));
		else
			appendlogline("] ");
		appendlogline(dstusrdir?"(%s:%s:%s) ":"(%s:%s) ",
			tty_name, cwd, dstusrdir);

		reset_conf();
		while (1) {
			reset_line_defaults();
			auth = do_match();
			if (auth == -1) { auth = 0; break; }
			if (auth) break;
		}

		/*
		 * Oh well... I do reset full dstusr info to implement cheats - run as invoker silently instead of failure
		 * I should not cancel any information about what user invoker tried to run as so
		 * I log another user info here
		 * To be sure I (re)set all variables
		 *
		 * Nasty hack maybe
		 */
		if (isflag(suflags, S_CHEAT)) {
			dstuid = dsteuid = srcuid;
			dstgid = dstegid = srcgid;
			dstusr = dsteusr = srcusr;
			dstgrp = dstegrp = srcgrp;
			dstgrps = srcgrps;
			memcpy(dstgids, srcgids, srcgsz*sizeof(int));
			dstgsz = srcgsz;
			appendlogline("cheat ");
			/* force auth to succeed */
			auth = 1;
		}

		/*
		 * More complex than "cheat": run as specified user info, silently.
		 * Implement mini do_match() parser
		 * The full format is "dstusr,dsteusr:dstgrp,dstegrp:dstgrps,dstgrps,..."
		 *
		 * It is being moved to %set to remove nasty ';' separator limit, since 1.9.3+.
		 */
		if (forceas) {
			char *ss, *dd, *tt = NULL, *pp;
			char *SS, *DD, *TT = NULL;
			int x = 0;

			ss = dd = forceas;
			while ((ss = strtok_r(dd, ":", &tt))) {
				if (dd) dd = NULL;
				switch (x) {
					case 0:
						pp = strchr(ss, ',');
						if (pp) {
							*pp = 0;
							dstusr = xstrdup(ss);
							dsteusr = xstrdup(pp+1);
						}
						else dstusr = dsteusr = xstrdup(ss);
						dstuid = uidbyname(dstusr);
						if (dstuid == NOUID) xerror("uidbyname(%s)", dstusr);
						dsteuid = uidbyname(dsteusr);
						if (dsteuid == NOUID) xerror("uidbyname(%s)", dsteusr);
						dstgid = dstegid = gidbyuid(dstuid);
						if (dstgid == NOGID) dstgid = dstegid = (gid_t)dstuid;
						dstgrp = dstegrp = namebygid(dstgid);
						dstgsz = _s(dstgids);
						if (getugroups(dstusr, dstgid, dstgids, &dstgsz) == -1) xerror("getugroups(%s, %u, <>)", dstusr, dstgid);
						dstgrps = build_usergroups(dstgsz, dstgids, 0);
						break;
					case 1:
						pp = strchr(ss, ',');
						if (pp) {
							*pp = 0;
							dstgrp = xstrdup(ss);
							dstegrp = xstrdup(pp+1);
						}
						else dstgrp = dstegrp = xstrdup(ss);
						dstgid = gidbyname(dstgrp);
						if (dstgid == NOGID) xerror("gidbyname(%s)", dstgrp);
						dstegid = gidbyname(dstegrp);
						if (dstgid == NOGID) xerror("gidbyname(%s)", dstegrp);
						break;
					case 2:
						SS = DD = ss;
						dstgsz = 0;
						while ((SS = strtok_r(DD, ",", &TT))) {
							if (DD) DD = NULL;
							tmpgid = gidbyname(SS);
							if (tmpgid == NOGID) xerror("gidbyname(%s)", SS);
							dstgids[dstgsz] = tmpgid; dstgsz++;
						}
						dstgrps = build_usergroups(dstgsz, dstgids, 0);
						break;
				}
				x++;
			}
			/* Unlike cheat - log full info */
			appendlogline("forceas=%s,%s:%s,%s[%s] ", dstusr, dsteusr, dstgrp, dstegrp, dstgrps);
			/* And force auth to succeed */
			auth = 1;
		}

		if (schrootdir && chrootdir) appendlogline("root=\"%s\" ", chrootdir);
		else if (!schrootdir && chrootdir) appendlogline("[root=\"%s\"] ", chrootdir);
		if (isflag(optflags, SI_OPT_a)) appendlogline("[%s]:", argv0);
		appendlogline(isflag(optflags, SI_OPT_A)?"\"-%s\"":"\"%s\"", cmdline);
		if (isflag(suflags, S_LOGARGV)) appendlogline("<%s>", logargv);
		if (*envline && envlinel && !isflag(suflags, S_LOGARGV)) {
			*(envline+envlinel-1) = 0; /* erase last comma */
			appendlogline(" [%s]", envline);
		}

#ifdef PATH_LOCKS
		if (!isflag(suflags, S_NOLOCK) && !mklockfile())
			blame("another " NAME " is running");
#endif
		if (!auth) blame("no permission");
		if (isflag(suflags, S_FAIL)) blame("no permission");
		if (isflag(suflags, S_NONID)
		&& (isnum(dstusr) || isnum(dsteusr)
		|| isnum(dstgrp) || isnum(dstegrp) || isnumgrps(dstgrps))) blame("only user names are permitted");
		if (isflag(suflags, S_NOZERO) && !strcmp(dstusr, SDEF_ID)) blame("zero uid request denied");
	}

	if (optflags & ~noptflags) {
		/* Ask user for password if option flag is banned, instead of punishing early. */
		if (isflag(suflags, S_PWINVALOPT)) {
			setflag(&suflags, S_PW);
			/* and let admin override then for which pw type is to ask */
		}
		else blame("protected cmdline switch");
	}
	if (isflag(suflags, S_TTY) && !isatty(0)) blame("not a tty");

	for (x = 1; x < NSIG; x++) signal(x, &s_sighandler);

	/* actually ask user for his password. */
	super_askpass();

_bypass: /* I am already superuser */
	if (issuper()) {
		for (x = 1; x < NSIG; x++) signal(x, &s_sighandler);
	}
	umask(dumask);

	/* Environment work */

	/* Prepare envvars to be kept over clear_user_environ */
	keep_user_envvars();
	keep_cfg_envvars(denvkeep);
	keep_cfg_envvars(envkeep);

	/* Remove all of environment if conditions are met */
	if (isflag(optflags, SI_OPT_LOGIN) || isflag(optflags, SI_OPT_E)) clear_user_environ();
	if (!issuper() && isflag(suflags, S_MINENV) && !isflag(optflags, SI_OPT_P)) clear_user_environ();

	/* If envpermit is set, then filter variables */
	if (!issuper()) {
		tpp = keepenvv;
		for (x = 0; tpp[x]; x += 2) {
			if (!cfg_permitted_envvar(tpp[x])) drop_envvar(tpp[x]);
		}
	}

	/* Keep/transfer user's vars prepared before */
	setkeepvars();

	/* Set all needed envvars */
	set_new_environ(isflag(optflags, SI_OPT_LOGIN) ? cmdline : NULL);

	/* Un/Set other envvars given in config */
	set_cfg_envvars(denvset);
	set_cfg_envvars(envset);
	unset_cfg_envvars(denvunset);
	unset_cfg_envvars(envunset);
	unset_ps_envvars(1, dpfxenvunset);
	unset_ps_envvars(1, pfxenvunset);
	unset_ps_envvars(0, dsufenvunset);
	unset_ps_envvars(0, sufenvunset);

	/* Let superuser override anything with -e */
	if (issuper()) setkeepvars();

/* Jump over */
	if (issuper()) goto _bypassaudit;

/*
 * Now a big audit code goes here: pass all collected precious information to external auditing program.
 * Last barrier where authentication can be aborted.
 */
#define auditsetenv(to, tol, fmt, s, d, x) \
	memzero(to, tol); \
	xsnprintf(to, tol, fmt, s, d); \
	*(auditenvp+x) = xstrdup(to); x++;

	if (!issuper() && auditcmd) {
		char *tmp;
		char *sv, *which, *ptmp;
		pid_t pid;

		tmp = xmalloc(_ALLOC_MAX);

		tpp = environ;
		for (x = 0; tpp[x]; x++);
		sv = build_protected_cmdline(x, tpp);

		x = 0;
		auditsetenv(tmp, _ALLOC_MAX, "%s=%u", "SUPER_PID", ourpid, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%u", "SUPER_PPID", parentpid, x);

		auditsetenv(tmp, _ALLOC_MAX, "%s=%u", "SUPER_TIMESTAMP", time(NULL), x);

		auditsetenv(tmp, _SUID_MAX, "%s=%u", "SUPER_UID", srcuid, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_USER", srcusr, x);
		auditsetenv(tmp, _SUID_MAX, "%s=%u", "SUPER_GID", srcgid, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_GROUP", srcgrp, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_GROUPS", srcgrps, x);

		auditsetenv(tmp, _SUID_MAX, "%s=%u", "SUPER_D_UID", dstuid, x);
		auditsetenv(tmp, _SUID_MAX, "%s=%u", "SUPER_D_EUID", dsteuid, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_D_USER", dstusr, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_D_EUSER", dsteusr, x);
		auditsetenv(tmp, _SUID_MAX, "%s=%u", "SUPER_D_GID", dstgid, x);
		auditsetenv(tmp, _SUID_MAX, "%s=%u", "SUPER_D_EGID", dstegid, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_D_GROUP", dstgrp, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_D_EGROUP", dstegrp, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_D_GROUPS", dstgrps, x);

		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_FLAGS", trigflags, x);

		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_LINE", trigline, x);

		ptmp = isflag(optflags, SI_OPT_LOGIN) ? dstusrshell : argv[optind];
		which = s_which(ptmp);
if (which) {	auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_BINPATH", which, x); }
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_CMDLINE", cmdline, x);
if (hashbang) {	auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_HASHBANG", hashbang, x); }

		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_USERENV", origenv, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_ENVIRON", sv, x);
		xfree(sv);

		auditsetenv(tmp, _ALLOC_MAX, "%s=%u", "SUPER_FIRST_ARG", optind, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_ARGS", logargvaudit, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "PATH", spath, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_PATH", spath, x);

#ifdef PATH_LOCKS
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_LOCKFILE", lockfile ? lockfile : "<unset>", x);
#endif

		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_TTY", tty_name, x);
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_CWD", cwd, x);
if (schrootdir && chrootdir) {
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_CHROOT", chrootdir, x);
}

		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_CONF", PATH_SUPERCONF, x);
#ifdef SYSLOG_SUPPORT
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_LOG", isflag(suflags, S_SYSLOG) ? "<syslog>" : logpath, x);
#else
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_LOG", logpath, x);
#endif
		auditsetenv(tmp, _ALLOC_MAX, "%s=%s", "SUPER_VERSION", _SUPER_VERSION, x);

		xfree(tmp);

		sv = xstrdup(auditcmd);
		s_strrep(sv, "\\ ", " ");
		audit_cmdline(auditcmd, auditargv, _s(auditargv));
		tpp = auditargv;
		if (*(auditargv+1)) tpp++;
		blocksleep(1);
		reseterr();
		auditrun = 1;
		x = forkexecve(*auditargv, tpp, auditenvp, &pid);
		if (errno) xerror("forkexecve");
		blocksleep(0);
		auditrun = 0;
		appendlogline(" {\"%s\"[%d]=%d}", sv, pid, x); xfree(sv);
		if (x != auditret) {
			if (x >= 252 && x <= 254) {
				setflag(&suflags, S_PW);
				switch (x) {
					case 252: setflag(&suflags, S_SUPW); break;
					case 253: setflag(&suflags, S_DSTPW); break;
					/* 254 is catched by S_PW, own user password */
				}
				/* actually ask user for his password. */
				super_askpass();
			}
			else blame("denied by external auditor program");
		}
	}
#undef auditsetenv

	if (isflag(suflags, S_WARNUSR)) warnusr();
	
	/* Do not log anything if "log" bit is cleared */
	if (!isflag(suflags, S_LOG)) undolog();
	else {
		if (!endlogline(0)) xerror("endlogline");
	}
/* ------------- LOGGING END ------------- */

_bypassaudit:
	close_conf();

	if (isflag(optflags, SI_OPT_LOGIN)) {
		s = NULL;
		if (isflag(optflags, SI_OPT_I)) loginshell = xstrdup(defsh);
		else loginshell = xstrdup(dstusrshell);
		s = basename(loginshell);
		n = strnlen(s, _ALLOC_MAX) + 2;
		argv0 = xmalloc(n);
		xsnprintf(argv0, n, "-%s", s);
		xchdir(dstusrdir);
	}

	if (isflag(optflags, SI_OPT_B)) ttydetach();
	s_closefrom(minfd);
#ifdef PATH_LOCKS
	unlockfile();
#endif
#ifndef NORESETRLIMITS
	restore_user_limits();
#endif
	setreslimits();
	if (isflag(optflags, SI_OPT_Q)) {
		if (setpriority(PRIO_PROCESS, 0, prio) == -1) xerror("setpriority(<>, %d)", prio);
	}
	if (chrootdir && (issuper() || schrootdir)) {
		if (chdir(chrootdir) == -1) xerror(chrootdir);
		if (chroot(chrootdir) == -1) xerror(chrootdir);
	}

#ifdef GROUPSLIMIT
	if (dstgsz > NGROUPS_MAX) dstgsz = NGROUPS_MAX;
#endif
/* CHANGING USER */
	if (setgroups(dstgsz, dstgids) == -1) xerror("setgroups");
	if (setregid(dstgid, dstegid) == -1) xerror("setregid");
	if (setreuid(dstuid, dsteuid) == -1) xerror("setreuid");

	if (!issuper() && dsteuid && open(PATH_SUPERCONF, O_RDONLY) != -1) xerrexit("super failed to change uids!");
	errno = 0;

/* |--^,--^,--^,--^,-- super - target border line --^,--^,--^,--^,--^,--^,--^,--^,--^,--^,--^,--^,--| */

	if (isflag(optflags, SI_OPT_dD))
		xchdir(dstusrdir);

	if (isflag(optflags, SI_OPT_LOGIN)) {
		char *t[2];

		unsetflag(&optflags, SI_OPT_b);
		t[0] = argv0; t[1] = NULL;
		x = execute(loginshell, t, 0);
		xexit(x);
	}

	if (argv[optind]) {
		char *orig = NULL;
	
		if (isflag(optflags, SI_OPT_A)) {
			n = strnlen(argv[optind], _ALLOC_MAX)+2;
			argv0 = xmalloc(n);
			xsnprintf(argv0, n, "-%s", argv[optind]);
		}
		if (argv0) {
			orig = argv[optind];
			argv[optind] = argv0;
		}

		if (issuper() || !*binpath)
			x = execute(argv0 ? orig : argv[optind], argv+optind, 0);
		else {
			strncat(binpath, argv0 ? orig : argv[optind], sizeof(binpath)-strnlen(binpath, sizeof(binpath)));
			x = execute(binpath, argv+optind, 1);
		}
		xexit(x);
	}
	else usage();

	xexit(0);
	return 0;
}
