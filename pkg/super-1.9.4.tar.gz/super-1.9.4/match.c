#include "super.h"

static char srcspec[_ALLOC_MAX+1], dstspec[_ALLOC_MAX+1], flgspec[_ALLOC_MAX+1], cmdpat[_CMDLINE_MAX+1];
static char tmp[_ALLOC_MAX], _spath[sizeof(spath)];

/* @exit call */
void __wipevars_match(void)
{
	memzero(tmp, sizeof(tmp));
	memzero(_spath, sizeof(_spath));
	memzero(srcspec, sizeof(srcspec));
	memzero(dstspec, sizeof(dstspec));
	memzero(flgspec, sizeof(flgspec));
	memzero(cmdpat, sizeof(cmdpat));
}

int do_match(void)
{
	char *ln;
	char *s, *d, *t; int x;
	const char *tp;
	int SF, OF, NOF;
	int ret = 0, X;

	if (!srcusr || !srcgrp || !srcgrps
	|| !dstusr || !dsteusr || !dstgrp || !dstegrp || !dstgrps || !cmdline) return -1;

/*
 * Parse a line of format:
 * "[srcusr]:[srcgrp:srcgrps,srcgrps,...] [dstusr,dsteusr]:[dstgrp,dstegrp]:[dstgrps,dstgrps,...] flag,flag,... cmdline ..."
 */

	ln = get_conf_line();
	if (!ln) return -1;
	xfree(trigline); trigline = xstrdup(ln);

	/* Skip unrelated lines (comments and such are already out) */
	if (!strncmp(ln, "%def", 4) || !strncmp(ln, "%user", 5)) return 0;
	/* If EOF mark is seen, break the loop completely */
	if (!strncmp(ln, "%eof", 4)) return -1;

	/* parse additional %set/%unset lines for flags that could not be fit into flgspec because of spaces */
	if (!strncmp(ln, "%set", 4)) { set_variable(ln+5); return 0; }
	if (!strncmp(ln, "%unset", 6)) { unset_variable(ln+7); return 0; }

	SF = suflags; OF = optflags; NOF = noptflags;

	__wipevars_match();
	
	X = sscanf(ln,
		"%"_SSALLOC_MAX"s %"_SSALLOC_MAX"s %"_SSALLOC_MAX"s %"_SCMDLINE_MAX"[^\n]",
		srcspec, dstspec, flgspec, cmdpat);
	if (X < 3) return 0; /* Not a valid spec: can't have empty cmd or flags */
	xfree(trigflags); trigflags = xstrdup(flgspec);

	/* No valid flags in flagspec? This is because part of cmdpat is inside flagspec */
	if (!resolve_flags(flgspec, NULL, NULL, NULL)) {
		if (*cmdpat) {
			xsnprintf(tmp, sizeof(tmp), "%s %s", flgspec, cmdpat);
			xsnprintf(cmdpat, sizeof(cmdpat), "%s", tmp);
		}
		else xsnprintf(cmdpat, sizeof(cmdpat), "%s", flgspec);
		memzero(tmp, sizeof(tmp));
		memzero(flgspec, sizeof(flgspec));
	}
	else resolve_flags(flgspec, &SF, &OF, &NOF);

	/* Fast check for certain flags, do not do unneeded work when it's obvious */
	if (isflag(SF, S_NOEUID) && strncmp(dstusr, dsteusr, _ALLOC_MAX) != 0) return 0;
	if (isflag(SF, S_NOEGID) && strncmp(dstgrp, dstegrp, _ALLOC_MAX) != 0) return 0;
	if (chrootdir) {
		if (!schrootdir) return 0;
		else if (fnmatch(schrootdir, chrootdir, 0) != 0) return 0;
	}
	else if (schrootdir && !chrootdir) return 0;
	if (fromtty) {
		if (fnmatch(fromtty, tty_name, 0) != 0) return 0;
	}

	/* Parse source user specification part */
	s = d = srcspec; t = NULL; x = 0;
	while ((s = strtok_r(d, ":", &t))) {
		if (d) d = NULL;
		switch (x) {
			case 0: /* srcusr */
				if (!strncmp(s, srcusr, sizeof(srcspec)-strnlen(s, sizeof(srcspec))) || !strcmp(s, _ANYUSR)) ret = 1;
				else return 0;
				break;
			case 1: /* srcgrp */
				if (!strncmp(s, srcgrp, sizeof(srcspec)-strnlen(s, sizeof(srcspec))) || !strcmp(s, _ANYUSR)) ret = 1;
				else return 0;
				break;
			case 2: /* srcgrps,... */
				if (!strncmp(s, srcgrps, sizeof(srcspec)-strnlen(s, sizeof(srcspec))) || !strcmp(s, _ANYUSR)) ret = 1;
				else if (strchr(s, '*') && !fnmatch(s, srcgrps, 0)) ret = 1;
				else if (strchr(s, '+')) {
					char *S, *D, *T;
					char *SS, *DD, *TT;
					int XX, YY;

					S = D = s; T = NULL; XX = YY = 0;
					while ((S = strtok_r(D, ",", &T))) {
						if (D) D = NULL;

						xsnprintf(tmp, sizeof(tmp), "%s", srcgrps);
						SS = DD = tmp;
						while ((SS = strtok_r(DD, ",", &TT))) {
							if (DD) DD = NULL;

							if (!strncmp(S+1, SS, sizeof(tmp)-strnlen(SS, sizeof(tmp)))) YY++;
						}

						XX++;
					}

					if (XX && XX == YY) ret = 1;
					else return 0;
				}
				else return 0;
				break;
		}
		x++;
	}

	/* Parse destination user specification part */
	if (!strcmp(dstspec, ":") || !strcmp(dstspec, "::")) { setflag(&ret, M_DANYUSR); goto _cmd; }
	s = d = dstspec; t = NULL; x = 0;
	while ((s = strtok_r(d, ":", &t))) {
		if (d) d = NULL;
		switch (x) {
			case 0: /* dstusr,dsteusr */
				if (!strcmp(s, _ANYUSR) || !strcmp(s, _ANYUSR "," _ANYUSR)) { setflag(&ret, M_DANYUSR); break; }
				tp = dstusr;
				/* "<same>,<same>" */
				if (!strcmp(s, _SAMEUSR) || !strcmp(s, _SAMEUSR "," _SAMEUSR)) {
					if (!strncmp(srcusr, dstusr, _ALLOC_MAX) && !strncmp(srcusr, dsteusr, _ALLOC_MAX)) {
						xsnprintf(tmp, sizeof(tmp), "%s", s);
						tp = tmp;
					}
				}
				if (strncmp(dstusr, dsteusr, _ALLOC_MAX) != 0) {
					/* I have single name in config, but
					   invoker requests seteuid - deny request */
					if (!strchr(s, ',')) return 0;
					/* "<same>,dsteusr" */
					if (strstr(s, _SAMEUSR ",")) {
						if (!strncmp(srcusr, dstusr, _ALLOC_MAX))
							xsnprintf(tmp, sizeof(tmp), _SAMEUSR ",%s", dsteusr);
					}
					/* "dstusr,<same>" */
					else if (strstr(s, "," _SAMEUSR)) {
						if (!strncmp(srcusr, dsteusr, _ALLOC_MAX))
							xsnprintf(tmp, sizeof(tmp), "%s," _SAMEUSR, dstusr);
					}
					/* "dstusr,*" */
					else if (strstr(s, "," _ANYUSR)) xsnprintf(tmp, sizeof(tmp), "%s," _ANYUSR, dstusr);
					/* "*,dsteusr" */
					else if (!strncmp(s, _ANYUSR ",", strlen(_ANYUSR ","))) xsnprintf(tmp, sizeof(tmp), _ANYUSR ",%s", dsteusr);
					/* "dstusr,dsteusr" */
					else xsnprintf(tmp, sizeof(tmp), "%s,%s", dstusr, dsteusr);
					tp = tmp;
				}
				if (!strncmp(s, tp, sizeof(dstspec)-strnlen(s, sizeof(dstspec)))) setflag(&ret, M_DUSR);
				else return 0;
				break;
			case 1: /* dstgrp,dstegrp */
				if (!strcmp(s, _ANYUSR) || !strcmp(s, _ANYUSR "," _ANYUSR)) { setflag(&ret, M_DANYGRP); break; }
				tp = dstgrp;
				if (!strcmp(s, _SAMEUSR) || !strcmp(s, _SAMEUSR "," _SAMEUSR)) {
					if (!strncmp(srcgrp, dstgrp, _ALLOC_MAX) && !strncmp(srcgrp, dstegrp, _ALLOC_MAX)) {
						xsnprintf(tmp, sizeof(tmp), "%s", s);
						tp = tmp;
					}
				}
				if (strncmp(dstgrp, dstegrp, _ALLOC_MAX) != 0) {
					if (!strchr(s, ',')) return 0;
					if (strstr(s, _SAMEUSR ",")) {
						if (!strncmp(srcgrp, dstgrp, _ALLOC_MAX))
							xsnprintf(tmp, sizeof(tmp), _SAMEUSR ",%s", dstegrp);
					}
					else if (strstr(s, "," _SAMEUSR)) {
						if (!strncmp(srcgrp, dstegrp, _ALLOC_MAX))
							xsnprintf(tmp, sizeof(tmp), "%s," _SAMEUSR, dstgrp);
					}
					else if (strstr(s, "," _ANYUSR)) xsnprintf(tmp, sizeof(tmp), "%s," _ANYUSR, dstgrp);
					else if (!strncmp(s, _ANYUSR ",", strlen(_ANYUSR ","))) xsnprintf(tmp, sizeof(tmp), _ANYUSR ",%s", dstegrp);
					else xsnprintf(tmp, sizeof(tmp), "%s,%s", dstgrp, dstegrp);
					tp = tmp;
				}
				if (!strncmp(s, tp, sizeof(dstspec)-strnlen(s, sizeof(dstspec)))) setflag(&ret, M_DGRP);
				else return 0;
				break;
			case 2: /* dstgrps,... */
				if (!strcmp(s, _ANYUSR)) setflag(&ret, M_DANYGPS);
				else if (!strncmp(s, dstgrps, sizeof(dstspec)-strnlen(s, sizeof(dstspec)))) setflag(&ret, M_DGPS);
				else return 0;
				break;
		}
		x++;
	}

	if (isflag(ret, M_DANYUSR) && !isflag(ret, M_DUSR) && !isflag(SF, S_USRONLY)) goto _cmd;

	/* if "usronly", then restrict user only to specifying target user */
	if (isflag(SF, S_USRONLY)) {
		unsetflag(&ret, M_DGRP);
		unsetflag(&ret, M_DANYGRP);
		unsetflag(&ret, M_DGPS);
		unsetflag(&ret, M_DANYGPS);
	}

	if (!isflag(ret, M_DGRP) && !isflag(ret, M_DANYGRP)) {
		tmpgid = gidbyuid(dstuid);
		if (tmpgid == NOGID) tmpgid = (gid_t)dstuid;
		if (tmpgid != dstgid) return 0;
		if (tmpgid != dstegid) return 0;
	}
	if (!isflag(ret, M_DGPS) && !isflag(ret, M_DANYGPS)) {
		tmpgsz = _s(tmpgids);
		if (getugroups(dstusr, dstgid, tmpgids, &tmpgsz) == -1) xerror("getugroups(%s, %u, <>)", dstusr, dstgid);
		if (tmpgsz != dstgsz) return 0;
		for (x = 0; x < tmpgsz; x++)
			if (tmpgids[x] != dstgids[x]) return 0;
	}

_cmd:
	if (ret) ret = 1;
	/* Finally, check command line */
	if (!strcmp(cmdpat, _ANYCMD)) goto _ret;

	if (*cmdpat == '[') { /* [wdir]:cmd specified */
		s = cmdpat+1;
		d = strchr(s, ']');
		if (d && *(d+1) == ':') {
			*d = 0; d += 2;
			if (!isflag(OF, SI_OPT_dD) && !fnmatch(s, cwd, 0)) {
				if (!strcmp(d, _ANYCMD)) goto _ret;
				memmove(cmdpat, d, sizeof(cmdpat)-strnlen(d, sizeof(cmdpat)));
			}
			else return 0;
		}
	}

	/* prepend $HOME/bin if "pathhome" */
	if (isflag(SF, S_PATHHOME))
		xsnprintf(_spath, sizeof(_spath), "%s/bin:%s", udirbyname(dstusr), spath);
	else xstrlcpy(_spath, spath, sizeof(_spath)-1);

	if (!isflag(OF, SI_OPT_LOGIN)) {
		if (is_abs_rel_cmdline(cmdline)) { /* match by absolute/relative path */
			xsnprintf(tmp, sizeof(tmp), "%s", cmdline);
			if (!fnmatch(cmdpat, tmp, 0)) goto _ret;
			else {
				xsnprintf(tmp, sizeof(tmp), "%s ", cmdline);
				if (!fnmatch(cmdpat, tmp, 0)) goto _ret;
				else return 0;
			}
		}
		else { /* match by safe path */
			s = d = _spath; t = NULL;
			while ((s = strtok_r(d, ":", &t))) {
				if (d) d = NULL;
				xsnprintf(tmp, sizeof(tmp), "%s/%s", s, cmdline);
				if (!fnmatch(cmdpat, tmp, 0)) {
					xsnprintf(binpath, sizeof(binpath), "%s/", s);
					goto _ret;
				}
				else {
					xsnprintf(tmp, sizeof(tmp), "%s/%s ", s, cmdline);
					if (!fnmatch(cmdpat, tmp, 0)) {
						xsnprintf(binpath, sizeof(binpath), "%s/", s);
						goto _ret;
					}
					else continue;
				}
			}
			return 0;
		}
	}
	else {
		if (!strncmp(cmdpat, cmdline, sizeof(cmdpat))) goto _ret;
		else return 0;
	}

_ret:
	/* Flags are stored only with successfull auth */
	suflags = SF; optflags = OF; noptflags = NOF;
	return ret;
}
