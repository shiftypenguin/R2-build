#include "super.h"

void s_sigblock(int n, int block)
{
	sigset_t ns;

	sigemptyset(&ns);
	sigaddset(&ns, n);
	sigprocmask(block ? SIG_BLOCK : SIG_UNBLOCK, &ns, NULL);
}

void s_sighandler(int n)
{
	if (auditrun) return; /* wait for audit verdict, all signals are blocked anyway */
	if (n == SIGCHLD) xexit(0); /* Just exit if lhexecvp()'ed exited earlier than super */
	if (isatty(0)) tcsetattr(0, TCSAFLUSH, &saneterm);
	if (isflag(suflags, S_PW)) fputc('\n', stderr);
	blame("got signal %u", n);
}
