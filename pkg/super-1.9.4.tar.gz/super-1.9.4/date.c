#include "super.h"

char *date_now(void)
{
	time_t t;
	char *r;

	t = time(NULL);
	r = ctime(&t);
	if (r) newline_to_nul(r, strlen(r));
	return xstrdup(r);
}
