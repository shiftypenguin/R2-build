#include "super.h"

static char tmp[_ALLOC_MAX];

/* @exit call */
void __wipevars_conf(void)
{
	memzero(tmp, sizeof(tmp));
}

char *get_conf_line(void)
{
	if (!conffile || ferror(conffile) || feof(conffile)) return NULL;

_again:
	if (!xfgets(confline, sizeof(confline)-1, conffile)) return NULL;
	if (iscomment(confline)) goto _again;

	return confline;
}

int open_conf(void)
{
	struct stat st;

	if (lstat(PATH_SUPERCONF, &st) == -1) return 0;
	if (!cfg_permission(&st)) {
		seterr("wrong mode");
		return 0;
	}
	conffile = fopen(PATH_SUPERCONF, "rb");
	if (!conffile) return 0;

	return 1;
}

#define __setflag(x, y) { setflag(x, y); ret = 1; }
#define __unsetflag(x, y) { unsetflag(x, y); ret = 1; }
#define __noptflag(z, x, y) { z ? unsetflag(x, y) : setflag(x, y); ret = 1; }
int resolve_flags(const char *sflags, int *SF, int *OF, int *NOF)
{
	char *s, *d, *t;
	int sf = 0, of = 0, nof = 0, ret = 0;
	int nopt; char copt;

	if (SF) sf = *SF;
	if (OF) of = *OF;
	if (NOF) nof = *NOF;
	xstrlcpy(tmp, sflags, sizeof(tmp)-1);
	s = d = tmp;
	while ((s = strtok_r(d, ",", &t))) {
		if (d) d = NULL;
		if (!strcmp(s, "log")) __setflag(&sf, S_LOG)
		else if (!strcmp(s, "nolog")) __unsetflag(&sf, S_LOG)
		if (!strcmp(s, "logfail")) __setflag(&sf, S_LOGFAIL)
		else if (!strcmp(s, "nologfail")) __unsetflag(&sf, S_LOGFAIL)
		if (!strcmp(s, "tty")) __setflag(&sf, S_TTY)
		else if (!strcmp(s, "notty")) __unsetflag(&sf, S_TTY)
		if (!strcmp(s, "pw")) __setflag(&sf, S_PW)
		else if (!strcmp(s, "nopw")) {
			__unsetflag(&sf, S_PW)
			__unsetflag(&sf, S_DSTPW)
		}
		if (!strcmp(s, "dstpw")) __setflag(&sf, S_DSTPW)
		if (!strcmp(s, "supw")) __setflag(&sf, S_SUPW)
		if (!strcmp(s, "pwinval")) __setflag(&sf, S_PWINVALOPT)
		if (!strcmp(s, "fail") || !strcmp(s, "false")) __setflag(&sf, S_FAIL)
#ifdef SYSLOG_SUPPORT
		if (!strcmp(s, "syslog")) __setflag(&sf, S_SYSLOG)
#endif
		if (!strcmp(s, "logargv")) __setflag(&sf, S_LOGARGV)
		else if (!strcmp(s, "nologargv")) __unsetflag(&sf, S_LOGARGV)
		if (!strcmp(s, "minenv") || !strcmp(s, "clearenv")) __setflag(&sf, S_MINENV)
		else if (!strcmp(s, "nominenv") || !strcmp(s, "userenv")) __unsetflag(&sf, S_MINENV)
		else if (!strcmp(s, "keepenv")) __setflag(&of, SI_OPT_P)
		if (!strcmp(s, "noeuid")) __setflag(&sf, S_NOEUID)
		if (!strcmp(s, "noegid")) __setflag(&sf, S_NOEGID)
		if (!strcmp(s, "nonid") || !strcmp(s, "nonumid")) __setflag(&sf, S_NONID)
		else if (!strcmp(s, "nid") || !strcmp(s, "numid")) __unsetflag(&sf, S_NONID)
		if (!strcmp(s, "usronly")) {
			__setflag(&sf, S_USRONLY)
			__setflag(&sf, S_NOEUID)
			__setflag(&sf, S_NOEGID)
			__setflag(&sf, S_NONID)
		}
		if (!strcmp(s, "superid")) __setflag(&sf, S_SUPERID)
		else if (!strcmp(s, "nosuperid")) __unsetflag(&sf, S_SUPERID)
		if (!strcmp(s, "destid")) __setflag(&sf, S_DESTID)
		else if (!strcmp(s, "nodestid")) __unsetflag(&sf, S_DESTID)
		if (!strcmp(s, "nozero")) __setflag(&sf, S_NOZERO)

		if (!issuper() && (!strncmp(s, "noopt_", 6) || !strncmp(s, "opt_", 4))) {
			nopt = !!(!strncmp(s, "no", 2)); /* if begin with "no" -> nopt = 1 */
			copt = nopt ? *(s+6) : *(s+4);

			switch (copt) {
				case 'd':
				case 'D': __noptflag(nopt, &nof, SI_OPT_dD); break;
				case 'e': __noptflag(nopt, &nof, SI_OPT_e); break;
				case 'S': __noptflag(nopt, &nof, SI_OPT_S); break;
				case 'a': __noptflag(nopt, &nof, SI_OPT_a); break;
				case 'A': __noptflag(nopt, &nof, SI_OPT_A); break;
				case 'P': __noptflag(nopt, &nof, SI_OPT_P); break;
				case 'I': __noptflag(nopt, &nof, SI_OPT_I); break;
				case 'b': __noptflag(nopt, &nof, SI_OPT_b); break;
				case 'B': __noptflag(nopt, &nof, SI_OPT_B); break;
				case 'x': __noptflag(nopt, &nof, SI_OPT_x); break;
				case 'n': __noptflag(nopt, &nof, SI_OPT_n); break;
				case 'F': __noptflag(nopt, &nof, SI_OPT_F); break;
				case 'C': __noptflag(nopt, &nof, SI_OPT_C); break;
				case 'L': __noptflag(nopt, &nof, SI_OPT_L); break;
				case 'Q': __noptflag(nopt, &nof, SI_OPT_Q); break;
				case 'p': __noptflag(nopt, &nof, SI_OPT_p); break;
				case 'v': __noptflag(nopt, &nof, SI_OPT_v); break;
				case 'l':
				case 'i': __noptflag(nopt, &nof, SI_OPT_LOGIN); break;
				case 'r': __noptflag(nopt, &nof, SI_OPT_r); break;
				default: break;
			}
		}
		if (!issuper() && !strcmp(s, "nologin")) __noptflag(1, &nof, SI_OPT_LOGIN);

		if (!strcmp(s, "ttydt")) __setflag(&of, SI_OPT_B)
		else if (!strcmp(s, "nottydt")) __unsetflag(&of, SI_OPT_B)
		if (!strcmp(s, "pathhome")) __setflag(&sf, S_PATHHOME)
		else if (!strcmp(s, "nopathhome")) __unsetflag(&sf, S_PATHHOME)
		if (!strcmp(s, "gohome")) { __setflag(&of, SI_OPT_dD) __setflag(&nof, SI_OPT_dD) }
		else if (!strcmp(s, "nogohome")) { __unsetflag(&of, SI_OPT_dD) __unsetflag(&nof, SI_OPT_dD) }
		if (!strcmp(s, "nolock")) __setflag(&sf, S_NOLOCK)
		if (!strcmp(s, "warnusr")) __setflag(&sf, S_WARNUSR)
		else if (!strcmp(s, "nowarnusr")) __unsetflag(&sf, S_WARNUSR)
		if (!strcmp(s, "cheat")) __setflag(&sf, S_CHEAT)
		else if (!strcmp(s, "nocheat")) __unsetflag(&sf, S_CHEAT)

/* Configurable flags */
		if (!strncmp(s, "pw", 2) && *(s+2) == '=') {
			ret = 1;
			xfree(linepw);
			linepw = xstrdup(s+3);
		}

		if (!strncmp(s, "umask", 5) && *(s+5) == '=') {
			ret = 1;
			s += 6;
			sscanf(s, "%o", (unsigned int *)&dumask);
		}

		if (!strncmp(s, "fromtty", 7) && *(s+7) == '=') {
			ret = 1;
			xfree(fromtty);
			fromtty = xstrdup(s+8);
		}
	}
	if (SF) { *SF = sf; ret = 1; }
	if (OF) { *OF = of; ret = 1; }
	if (NOF) { *NOF = nof; ret = 1; }

	return ret;
}

int readin_defaults(void)
{
	char *ln, *s;

	reset_conf();

	resolve_flags(DEFAULT_FLAGS, &suflags, &optflags, &noptflags);

/* Parse a line of format "%def flagname" */
	while ((ln = get_conf_line())) {
		if (!strncmp(ln, "%def", 4)) {
			ln += 5;

			resolve_flags(ln, &suflags, &optflags, &noptflags);

			if (!strncmp(ln, "nohard", 6)) reset_builtin_defaults();
			if (!strncmp(ln, "silent", 6)) s_quiet = 1;

			if (!strncmp(ln, "delay", 5)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					delay = atol(s+1);
				}
			}

			else if (!strncmp(ln, "spath", 5)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					xstrlcpy(spath, s+1, sizeof(spath)-1);
				}
			}

			else if (!strncmp(ln, "logfile", 7)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					xstrlcpy(logpath, s+1, sizeof(logpath)-1);
				}
			}

			else if (!strncmp(ln, "prompt", 6)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					if (isfmtstr(s+1, 's', 1, 1)) xstrlcpy(prompt, s+1, sizeof(prompt)-1);
				}
			}

			else if (!strncmp(ln, "minfd", 5) && !isflag(optflags, SI_OPT_C)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					minfd = atoi(s+1);
				}
			}

			else if (!strncmp(ln, "maxfd", 5)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					maxfd = atoi(s+1);
				}
			}

			else if (!strncmp(ln, "denymsg", 7)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0;
					xstrlcpy(denymsg, s+1, sizeof(denymsg)-1);
				}
			}

			else if (!strncmp(ln, "envset", 6) && *(ln+6) == '=' && *(ln+7) == '[') {
				*(ln+strnlen(ln, sizeof(confline)-1)-1) = 0;
				if (!denvset) denvset = xstrdup(ln+8);
				else xastrncat(&denvset, ln+8, strnlen(ln+8, sizeof(confline)-1));
			}

			else if (!strncmp(ln, "envunset", 8) && *(ln+8) == '=' && *(ln+9) == '[') {
				*(ln+strnlen(ln, sizeof(confline)-1)-1) = 0;
				if (!denvunset) denvunset = xstrdup(ln+10);
				else xastrncat(&denvunset, ln+10, strnlen(ln+10, sizeof(confline)-1));
			}

			else if (!strncmp(ln, "envkeep", 7) && *(ln+7) == '=' && *(ln+8) == '[') {
				*(ln+strnlen(ln, sizeof(confline)-1)-1) = 0;
				if (!denvkeep) denvkeep = xstrdup(ln+9);
				else xastrncat(&denvkeep, ln+9, strnlen(ln+9, sizeof(confline)-1));
			}
			else if (!strncmp(ln, "pfxenvunset", 11) && *(ln+11) == '=' && *(ln+12) == '[') {
				*(ln+strnlen(ln, sizeof(confline)-1)-1) = 0;
				if (!dpfxenvunset) dpfxenvunset = xstrdup(ln+13);
				else xastrncat(&dpfxenvunset, ln+13, strnlen(ln+13, sizeof(confline)-1));
			}
			else if (!strncmp(ln, "sufenvunset", 11) && *(ln+11) == '=' && *(ln+12) == '[') {
				*(ln+strnlen(ln, sizeof(confline)-1)-1) = 0;
				if (!dsufenvunset) dsufenvunset = xstrdup(ln+13);
				else xastrncat(&dsufenvunset, ln+13, strnlen(ln+13, sizeof(confline)-1));
			}

			else if (!strcmp(ln, "loguts")) setflag(&suflags, S_LOGUTS);

			/* tf=s,u,u,u,u */
			else if (!strncmp(ln, "tf", 2)) {
				s = strchr(ln, '=');
				if (s) {
					*s = 0; ln = s+1;
					if (sscanf(ln, "%63[^,\n],%u,%u,%u,%u", localid, &offset, &passes, &saltlen, &datalen) < 5) {
						seterr("invalid tf=s,u,u,u,u options specified");
						return 0;
					}
					noskconf = 1;
				}
			}
		}
	}

	return 1;
}

void readin_usermaps(void)
{
	char *ln, *s;
	char *user, *hash, *udir, *shell;
	uid_t u; gid_t g;
	int x;

	/* init a struct */
	for (x = 0; x < _s(umap); x++) {
		memzero(&umap[x], sizeof(struct usermap));
		umap[x].uid = NOUID;
		umap[x].gid = NOGID;
	}

	reset_conf();

	while ((ln = get_conf_line())) {
		user = hash = udir = shell = NULL;
		u = NOUID; g = NOGID;
		if (!strncmp(ln, "%user", 5)) {
			ln += 6;
			if (strchr(ln, ':')) { /* new passwd format (omitting gecos) */
				char *ss, *dd, *tt = NULL;
				int x = 0;
				ss = dd = ln;
				while ((ss = strtok_r(dd, ":", &tt))) {
					if (dd) dd = NULL;
					switch (x) {
						case 0:
							user = ss;
							break;
						case 1:
							hash = ss;
							break;
						case 2:
							u = (uid_t)atoi(ss);
							break;
						case 3:
							g = (gid_t)atoi(ss);
							break;
						case 4:
							udir = ss;
							break;
						case 5:
							shell = ss;
							break;
					}
					x++;
				}
			}
			else if ((s = strchr(ln, ' '))) { /* old "user hash" format */
				*s = 0; s++;
				hash = s;
				user = ln;
			}
			else continue;

			if (umapidx >= _s(umap)) break;
			umap[umapidx].user = xstrdup(user);
			umap[umapidx].hash = xstrdup(hash);
			if (u != NOUID) umap[umapidx].uid = u;
			if (g != NOGID) umap[umapidx].gid = g;
			if (udir) umap[umapidx].udir = xstrdup(udir);
			if (shell) umap[umapidx].shell = xstrdup(shell);
			umapidx++;
		}
	}
}

/* handle %set/%unset specification */
void set_variable(const char *spec)
{
	char *s, *d;

	if (!spec || !*spec) return;
	xstrlcpy(tmp, spec, sizeof(tmp)-1);

	if (!strncmp(tmp, "silent", 6)) {
		s_quiet = 1;
		return;
	}

	s = tmp;
	d = strchr(s, '=');
	if (!d) return; d++;

	if (!strncmp(s, "audit", 5) && *(s+5) == '=' && *(s+6) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(auditcmd);
		auditcmd = xstrdup(s+7);
	}

	if (!strncmp(s, "auditret", 8) && *(s+8) == '=') {
		s += 9;
		sscanf(s, "%d", (int *)&auditret);
	}

	if (!strncmp(s, "envset", 6) && *(s+6) == '=' && *(s+7) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(envset);
		envset = xstrdup(s+8);
	}
	else if (!strncmp(s, "envunset", 8) && *(s+8) == '=' && *(s+9) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(envunset);
		envunset = xstrdup(s+10);
	}
	else if (!strncmp(s, "envkeep", 7) && *(s+7) == '=' && *(s+8) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(envkeep);
		envkeep = xstrdup(s+9);
	}
	else if (!strncmp(s, "pfxenvunset", 11) && *(s+11) == '=' && *(s+12) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(pfxenvunset);
		pfxenvunset = xstrdup(s+13);
	}
	else if (!strncmp(s, "sufenvunset", 11) && *(s+11) == '=' && *(s+12) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(sufenvunset);
		sufenvunset = xstrdup(s+13);
	}
	else if (!strncmp(s, "envpermit", 9) && *(s+9) == '=' && *(s+10) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(envpermit);
		envpermit = xstrdup(s+11);
	}

	if (!strncmp(s, "root", 4) && *(s+4) == '=') {
		xfree(schrootdir);
		schrootdir = xstrdup(s+5);
	}

	if (!strncmp(s, "forceas", 7) && *(s+7) == '=' && *(s+8) == '[') {
		*(s+strnlen(s, sizeof(tmp)-1)-1) = 0;
		xfree(forceas);
		forceas = xstrdup(s+9);
	}
}

void unset_variable(const char *name)
{
	if (!name || !*name) return;

	if (!strncmp(name, "silent", 6)) s_quiet = 0;

	if (!strcmp(name, "audit")) xfree(auditcmd);
	if (!strcmp(name, "auditret")) auditret = 0;

	if (!strcmp(name, "envset")) xfree(envset);
	if (!strcmp(name, "envunset")) xfree(envunset);
	if (!strcmp(name, "envkeep")) xfree(envkeep);
	if (!strcmp(name, "pfxenvunset")) xfree(pfxenvunset);
	if (!strcmp(name, "sufenvunset")) xfree(sufenvunset);
	if (!strcmp(name, "envpermit")) xfree(envpermit);

	if (!strcmp(name, "root")) xfree(schrootdir);
	if (!strcmp(name, "forceas")) xfree(forceas);
}

void close_conf(void)
{
	if (conffile) {
		fclose(conffile);
		conffile = NULL;
	}
}
