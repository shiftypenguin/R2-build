#include "super.h"

unsigned int getrand(unsigned int s, unsigned int d)
{
	int f;
	unsigned int r;

	f = open("/dev/urandom", O_RDONLY);
	if (f == -1) xerror("/dev/urandom");
	if (read(f, &r, sizeof(int)) == -1) xerror("read(/dev/urandom)");
	close(f);

	r = r % (d - s + 1 == 0 ? d - s : d - s + 1) + s;
	return r;
}

char *mksalt(void)
{
	unsigned int l;
	char *r, *R, c;

	l = getrand(6, 18);
	r = R = xmalloc(l+5);
	strcpy(r, "$U$"); r += 3;
	while (l) {
		c = (char)getrand(0, 255);
		if ((c >= 'a' && c <= 'z')
		   || (c >= 'A' && c <= 'Z')
		   || (c >= '0' && c <= '9')) { *r = c; r++; l--; }
	}
	*r = '$';
	*(r+1) = 0;

	return R;
}
