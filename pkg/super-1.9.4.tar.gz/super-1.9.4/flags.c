#include "super.h"

int isflag(int flags, int flag)
{
	return (!!(flags & flag));
}

void setflag(int *flags, int flag)
{
	*flags |= flag;
}

void unsetflag(int *flags, int flag)
{
	*flags &= ~flag;
}
