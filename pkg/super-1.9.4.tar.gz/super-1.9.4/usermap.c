#include "super.h"

char *usermap_gethash(const char *user)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].user) if (!strncmp(umap[x].user, user, _ALLOC_MAX)) return umap[x].hash;
	return NULL;
}

uid_t usermap_getuid(const char *user)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].user) if (!strncmp(umap[x].user, user, _ALLOC_MAX)) return umap[x].uid;
	return NOUID;
}

gid_t usermap_getgid(const char *user)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].user) if (!strncmp(umap[x].user, user, _ALLOC_MAX)) return umap[x].gid;
	return NOGID;
}

char *usermap_getudir(const char *user)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].user) if (!strncmp(umap[x].user, user, _ALLOC_MAX)) return umap[x].udir;
	return NULL;
}

char *usermap_getushell(const char *user)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].user) if (!strncmp(umap[x].user, user, _ALLOC_MAX)) return umap[x].shell;
	return NULL;
}

char *usermap_getnamebyuid(uid_t uid)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].uid != NOUID) if (umap[x].uid == uid) return umap[x].user;
	return NULL;
}

gid_t usermap_getgidbyuid(uid_t uid)
{
	int x;

	for (x = 0; x < umapidx; x++) if (umap[x].uid != NOUID) if (umap[x].uid == uid) return umap[x].gid;
	return NOGID;
}
