#include "super.h"

int s_quiet;

pid_t ourpid, parentpid;
char super[_ALLOC_MAX], confline[_ALLOC_MAX], logline[_ALLOC_MAX], envline[_ALLOC_MAX];
size_t loglinel, envlinel;
char binpath[PATH_MAX];
FILE *conffile, *logfile;
int suflags, optflags, noptflags;
char spath[_ALLOC_MAX] = SAFE_PATH, logpath[PATH_MAX] = PATH_SUPERLOG;
char prompt[256] = PASSWORD_PROMPT, denymsg[256] = DENY_MSG;
char *logargv, *logargvaudit, *origenv;
char *trigline, *trigflags;
uint64_t delay = DELAY_WRPASS;
int minfd = 3, maxfd = -1;
mode_t dumask = DEFAULT_UMASK;
#ifdef PATH_LOCKS
char *lockfile;
#endif

struct termios saneterm;

int opt_x_cnt;
int opt_V_cnt;
struct usermap umap[_NUM_MAX];
int umapidx;

/* Always kept environment variables */
char *keepenvv_always[] = {
	"TERM", "DISPLAY", NULL
};

char *keepenvv[_NUM_MAX];
char *unkeepenvv[_NUM_MAX];

/*
 * Always cleared environment variables.
 * This is a list of nasty vars that modify
 * various program paths in TARGET program.
 * I can't support all of them (and especially vars in
 * third-party programs), but common linker/loader/shell
 * vars are banned here.
 *
 * You can always add more with "envunset=[]" in config.
 *
 * NOTE: superuser can override and keep ALL of those!
 */
char *clearenvv[] = {
	"PATH", "MAIL",
	"LD_LIBRARY_PATH", "LD_PRELOAD", "LIBPATH", "LIBRARY_PATH",
	"HOSTALIASES", "LOCALDOMAIN", "LOCPATH",
	"RESOLV_HOST_CONF", "RES_OPTIONS", "GETCONF_DIR",
	"_", "IFS", "CDPATH", "ENV", "BASH_ENV", "PS1", "PS2", "PS3", "PS4",
	"INPUTRC", "KRB_CONF", "KRB5_CONFIG",
	"NLSPATH", "LANG", "LANGUAGE", "PATH_LOCALE",
	"TERMINFO", "TERMINFO_DIRS", "TERMPATH", "TERMCAP",
	"TMPDIR", "TZDIR",
	"HISTFILE", NULL
};

/*
 * Hardcoded prefixes of common BAD environment vars.
 * You can define more with pfxenvunset=[].
 */
char *clearpfxenvv[] = {
	"LD_", "DYLD_",
	"_RLD", "LDR_",
	"MALLOC_", "LIBC_", "MUSL_",
	/* There are probably more. I just don't know about all of them. */
	NULL
};

/*
 * Same, but suffixes (ends)
 * You can define more with sufenvunset=[].
 */
char *clearsufenvv[] = {
	"_PATH", "_ACE",
	NULL
};

/* Resource limit strings, format: nrlim:soft:hard */
char *rlims[_NUM_MAX];

uid_t srcuid, srceuid, dstuid, dsteuid;
gid_t srcgid, srcegid, dstgid, dstegid, tmpgid;
gid_t srcgids[NGIDS], dstgids[NGIDS];
gid_t tmpgids[NGIDS];
int srcgsz, dstgsz;
int tmpgsz;
char *srcusr, *srcgrp, *dstusr, *dstgrp;
char *srceusr, *srcegrp, *dsteusr, *dstegrp;
char *srcgrps, *dstgrps;
char *suusr;
char *cmdline, *cwd;
char *schrootdir, *chrootdir;
char *denvset, *denvunset, *denvkeep;
char *envset, *envunset, *envkeep;
char *dpfxenvunset, *dsufenvunset;
char *pfxenvunset, *sufenvunset;
char *envpermit;
char *linepw;
char *forceas;
char *auditargv[_NUM_MAX], *auditenvp[_NUM_MAX];
char *auditcmd;
int auditret = 0;
int auditrun = 0; /* indicates that audit program has been started but not stopped yet, for s_sighandler */
char *fromtty, *tty_name;

int auth;

char *progname;
char *errstr;
char defsh[] = DEFAULT_SHELL;
char defroot[16] = "/";

int noblame;
