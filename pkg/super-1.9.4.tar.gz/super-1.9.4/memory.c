#include "super.h"

typedef uint32_t LTYPE;

/* used temporarily */
static char testbumper[_ALLOC_BUMPER];

static void __bumper_is_bad(void)
{
	xerrexit(NAME " bumper damaged (attack or bug)");
}

void memzero(void *p, size_t l)
{
	memset(p, 0, l);
}

/*
 * Allocate memory with bumpers.
 * Bumper purpose is to track the changes in nonchangeable area,
 * such as (small) buffer overflows / underflows and other such problems.
 *
 * Bumper is not just an area filled with constant, but contains
 * a 4 byte NUL beginning / ending to catch the string functions. If it is overwritten too, then
 * there will be disasters of course.
 */
static void *xsalloc(size_t n)
{
	void *r;
	char *bumper;
	LTYPE *sz;

	if (n > _XSALLOC_MAX) return NULL;
	if (!n) n++;

	r = malloc(n + (_ALLOC_BUMPER * 2) + sizeof(LTYPE)); /* ACTUAL ALLOCATION IS HERE! */
	if (!r) return NULL;

	sz = (LTYPE *)r;
	*sz = (LTYPE)n;

	/* skip the size marker area */
	r += sizeof(LTYPE);

	/* the beginning bumper [0000CCCC...CCCC0000] */
	bumper = r;
	memset(bumper, 'C', _ALLOC_BUMPER);
	memzero(bumper, 4);
	bumper += _ALLOC_BUMPER - 4;
	memzero(bumper, 4);

	/* rewind to user area */
	r += _ALLOC_BUMPER;

	/* and ending bumper [CCCCCCCC...CCCC0000] */
	bumper = (r+n);
	memset(bumper, 'C', _ALLOC_BUMPER);
	bumper += _ALLOC_BUMPER - 4;
	memzero(bumper, 4);

	/* zero and return user area */
	memzero(r, n);
	return r;
}

static void xsfree(void *p)
{
	void *actual = p-_ALLOC_BUMPER-sizeof(LTYPE);
	char *bumper;
	LTYPE *sz;

	sz = (LTYPE *)actual;

	/*
	 * if it happened to overwrite size marker also - the bumper is bad
	 * xsalloc() allocates at least 1 byte if caller wanted 0, hence !*sz check.
	 * if something is messed with zero memset.
	 */
	if (!*sz || *sz > _XSALLOC_MAX) __bumper_is_bad();

	/* make test beginning bumper to compare */
	memset(testbumper, 'C', _ALLOC_BUMPER);
	memzero(testbumper, 4);
	memzero(testbumper+_ALLOC_BUMPER-4, 4);

	/* test the beginning bumper */
	bumper = actual+sizeof(LTYPE);

	if (memcmp(bumper, testbumper, _ALLOC_BUMPER) != 0)
		__bumper_is_bad();

	/* make test ending bumper to compare */
	memset(testbumper, 'C', _ALLOC_BUMPER);
	memzero(testbumper+_ALLOC_BUMPER-4, 4);

	/* test the ending bumper */
	bumper = actual+sizeof(LTYPE)+_ALLOC_BUMPER+*sz;

	if (memcmp(bumper, testbumper, _ALLOC_BUMPER) != 0)
		__bumper_is_bad();

	/* remove the data from testbumper */
	memzero(testbumper, _ALLOC_BUMPER);

	/* return clean memory to system */
	memzero(p, *sz);
	free(actual); /* ACTUAL FREE IS HERE */
}

static void *xsrealloc(void *p, size_t n)
{
	void *actual = p-_ALLOC_BUMPER-sizeof(LTYPE);
	LTYPE *sz;
	void *new;

	sz = (LTYPE *)actual;

	if (!n || n > _XSALLOC_MAX) {
		xsfree(p);
		return NULL;
	}

	if (*sz != n) {
		new = xsalloc(n);
		if (!new) return NULL;

		memcpy(new, p, n);
		xsfree(p);

		return new;
	}

	return p;
}

static void *__xmalloc(size_t n, int err)
{
	void *r = xsalloc(n);

	if (!r && err) {
		errstr = NULL;
		xerror("xsalloc");
		return NULL;
	}

	return r;
}

void *xmalloc(size_t n)
{
	return __xmalloc(n, 1);
}

void *nmalloc(size_t n)
{
	return __xmalloc(n, 0);
}

void *xrealloc(void *p, size_t n)
{
	void *r = xsrealloc(p, n);
	if (!n) {
		xerrexit("xrealloc called with n==0.");
	}
	if (!r && n) {
		errstr = NULL;
		xerror("xrealloc");
		return NULL;
	}
	else return r;
}

void *nfree(void *p)
{
	xsfree(p);
	return NULL;
}
