#include "super.h"

/*
 * Accept simple single char prefix names
 */
long xpatol(const char *s)
{
	char pfx[2] = {0};
	char N[128];
	size_t l;

	if (!s) return 0;

	strncpy(N, s, sizeof(N));
	l = strnlen(N, sizeof(N));
	*pfx = *(N+l-1);

	if (isnum(pfx) || *pfx == 'B' || *pfx == 'c') return atol(N);
	else if (*pfx == 'b') return atol(N)*512;
	else if (*pfx == 'k' || *pfx == 'K') return atol(N)*1024;
	else if (*pfx == 'm' || *pfx == 'M') return atol(N)*1024*1024;
	else if (*pfx == 'g' || *pfx == 'G') return atol(N)*1024*1024*1024;
	else return atol(N);
}
