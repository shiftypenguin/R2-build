#include "super.h"

static char *ppathret;

/* @exit call */
void __wipevars_cmdline(void)
{
	if (ppathret) memzero(ppathret, _CMDLINE_MAX);
}

char *build_cmdline(int argc, char **argv, int format)
{
	char *cmdb, *fmt, *r;
	size_t l, cmdl;
	int x;

	for (x = 0, l = 0; x < argc && *(argv+x); x++) {
		l += strnlen(*(argv+x), _XSALLOC_MAX); l += 3;
	}

	cmdb = xmalloc(l+1);

	if (format) fmt = "\"%s\",";
	else fmt = "%s ";

	for (x = 0, cmdl = 0; x < argc && *(argv+x) && cmdl < l; x++) {
		if (!format && strchr(*(argv+x), ' ')) fmt = "\"%s\" ";
		cmdl += xsnprintf(cmdb+cmdl, l-cmdl, fmt, *(argv+x));
		if (!format) fmt = "%s ";
	}
	*(cmdb+cmdl-1) = 0;

	r = xstrdup(cmdb);

	xfree(cmdb);
	return r;
}

char *build_protected_cmdline(int argc, char **argv)
{
	char *cmdb, *cmdp, *r;
	size_t l, t, cmdl;
	int x;

	for (x = 0, l = 0; x < argc && *(argv+x); x++) {
		l += strnlen(*(argv+x), _XSALLOC_MAX); l++;
	}

	cmdb = xmalloc(l+1);

	for (x = 0, cmdl = 0; x < argc && *(argv+x) && cmdl < l; x++) {
		t = strnlen(*(argv+x), l-cmdl);
		memcpy(cmdb+cmdl, *(argv+x), t);
		cmdl += t; cmdl++;
	}

	cmdp = xmalloc(cmdl*2);
	base64_encode(cmdp, cmdb, cmdl);
	xfree(cmdb);

	r = xstrdup(cmdp);
	xfree(cmdp);

	return r;
}

void audit_cmdline(char *p, char **argout, int argrem)
{
	char *s, *d;
	int x, y;
	size_t l = strnlen(p, _ALLOC_MAX);

	if (!p) return;

	argrem--;
	s = d = p; x = y = 0;
	while (1) {
		if (*d == '\"' && (d-p && *(d-1) != '\\')) {
			memmove(d, d+1, l-(d-p)); l--;
			if (!x) x = 1; else x = 0;
			continue;
		}
		if (y || (*d == ' ' && (d-p && *(d-1) != '\\') && !x)) {
			*d = 0;
			s_strrep(s, "\\ ", " ");
			s_strrep(s, "\\\"", "\"");
			if (argrem >= 0) {
				*(argout) = s; *(argout+1) = NULL; argout++; argrem--;
			}
			s = d+1;
		}
		if (y) break;
		d++; if (!*d) y = 1;
	}
}

/*
 * Unix abs/relative semantics:
 * 1. "/" - absolute
 * 2. "./" - relative
 * 3. "../" - relative
 */
int is_abs_rel_cmdline(const char *cmdline)
{
	if (*cmdline == '/')
		return 1;
	else if ((*cmdline == '.' && *(cmdline+1) == '/')
		|| (*cmdline == '.' && *(cmdline+1) == '.' && *(cmdline+2) == '/'))
		return 2;

	return 0;
}

/* Pure `which` like, running over spath */
char *s_which(const char *progname)
{
	static char pathret[_CMDLINE_MAX];
	char *_spath, *s, *d, *t;
	int x;

	memzero(pathret, sizeof(pathret));

	x = is_abs_rel_cmdline(progname);
	if (x) {
		if (x == 1) xstrlcpy(pathret, progname, _CMDLINE_MAX);
		else if (x == 2) xsnprintf(pathret, sizeof(pathret), "%s/%s", cwd, progname);
		return pathret;
	}

	_spath = xmalloc(sizeof(spath));

	memcpy(_spath, spath, sizeof(spath));
	s = d = _spath; t = NULL; x = 0;
	while ((s = strtok_r(d, ":", &t))) {
		if (d) d = NULL;

		xsnprintf(pathret, sizeof(pathret), "%s/%s", s, progname);
		errno = 0;
		if ((access(pathret, X_OK) == 0) && !errno) {
			x = 1;
			break;
		}
	}

	xfree(_spath);

	if (x) return pathret;
	return NULL;
}
