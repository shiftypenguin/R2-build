#include "super.h"

void getpasswd(char *password, size_t pwdlen, const char *fmt, ...)
{
	int fd;
	struct termios s, t;
	ssize_t l;
	va_list ap;

	va_start(ap, fmt);

	if ((fd = open("/dev/tty", O_RDONLY|O_NOCTTY)) < 0) fd = 0;

	tcgetattr(fd, &t);
	s = t;
	t.c_lflag &= ~ECHO;
	t.c_lflag |= ICANON;
	t.c_iflag &= ~(INLCR|IGNCR);
	t.c_iflag |= ICRNL;
	tcsetattr(fd, TCSAFLUSH, &t);
	tcdrain(fd);

	vfprintf(stderr, fmt, ap);
	fflush(stderr);

	l = read(fd, password, pwdlen);
	if (l >= 0) {
		if (l > 0 && password[l-1] == '\n') l--;
		password[l] = 0;
	}

	fputc('\n', stderr);
	fflush(stderr);

	tcsetattr(fd, TCSAFLUSH, &s);

	if (fd > 2) close(fd);

	va_end(ap);
}

/* Used in reading a password from fd */
int fdgetstring(int fd, char *s, size_t n)
{
	ssize_t l;

	l = read(fd, s, n);
	if (l >= 0) {
		if (l > 0 && s[l-1] == '\n') l--;
		s[l] = 0;
	}
	else return 0;

	return 1;
}

char *xttyname(int fd)
{
	char *p;
	p = ttyname(fd);
	if (!p) p = "not a tty";

	return xstrdup(p);
}

