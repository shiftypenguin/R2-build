#include "super.h"

void reset_builtin_defaults(void)
{
	*keepenvv_always = *clearenvv = *clearpfxenvv = *clearsufenvv = NULL;
}

void reset_line_defaults(void)
{
	dumask = DEFAULT_UMASK;
	xfree(linepw);
	xfree(fromtty);
}
