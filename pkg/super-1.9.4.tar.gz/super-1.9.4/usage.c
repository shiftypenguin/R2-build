#include "super.h"

void usage(void)
{
	if (if_quiet) xexit(0);

	printf("usage: %s", progname);

	printf(" [-uU user/uid] [-gG group/gid] [-sS gid,group,...]\n");
	printf("\t[-tTxX] [-e VAR=VAL] [-a argv0] [-c vcmd] [-C minfd]\n");
	printf("\t[-d chdir] [-F fd] [-L rlimspec] [-Q prio] [-R newroot]\n");
	printf("\t[-AbBDEfHIlnpPrvV] [-M pat str] [--]");

	printf(" cmdline ...\n");

	printf("run %s with -h to see full help text\n", progname);
	xexit(1);
}

void usage_long(void)
{
	if (if_quiet) xexit(0);

	printf("usage: %s [opts] [--] cmdline ...\n\n", progname);

	printf("  -u uid/user: set uid to specified user or uid\n");
	printf("  -U euid/user: set euid to specified user or uid\n");
	printf("  -g gid/group: set gid to specified group or gid\n");
	printf("  -G egid/group: set egid to specified group or gid\n");
	printf("  -s grouplist: set additional groups to specified grouplist\n");
	printf("  -S grouplist: add/remove groups from grouplist\n");
	printf("  -t: set euid to superuser\n");
	printf("  -T: set egid to superuser\n");
	printf("  -x: run as current user, not target\n");
	printf("  -xx: run as current user, preserve current groups\n");
	printf("  -X: run as current user, reset grouplist to current gid\n\n");
	printf("  -a argv[0]: set target program argv[0] to this value\n");
	printf("  -A: place a '-' in beginning of argv[0] of target program\n");
	printf("  -b: run program in background, return immediately\n");
	printf("  -B: detach terminal to prevent tty hijacking\n");
	printf("  -c cmd,cmd,...: execute virtual command:\n");
	printf("    id: print id(1)-formatted userid information (without setuid)\n");
	printf("    uid: prints real user id\n");
	printf("    gid: prints real group id\n");
	printf("    gids: prints all group ids\n");
	printf("    euid: prints effective user id\n");
	printf("    egid: prints effective group id\n");
	printf("    user: prints real user name\n");
	printf("    group: prints real group name\n");
	printf("    euser: prints effective user name\n");
	printf("    egroup: prints effective group name\n");
	printf("    groups: prints all group names\n");
	printf("    suser: prints superuser name\n");
	printf("    udir: print user's directory\n");
	printf("    shell: print user's shell\n");
	printf("   (a list of comma separated commands may be given)\n");
	printf("  -C minfd: set minimal fd from which begin to close leakage fds\n");
	printf("  -d dir: change working directory to dir\n");
	printf("  -D: change working directory to user's directory\n");
	printf("  -e VAR=VAL: set environment variable\n");
	printf("  -E: start with empty environment\n");
	printf("  -f: do not read config file. Only superuser can do this\n");
	printf("  -F fd: if password is required, read it from file descriptor fd\n");
	printf("  -H: make a hash and print it to stdout. Only superuser can do this\n");
	printf("  -l: start a login shell\n");
	printf("  -I: start a login shell, but always use %s as login shell\n", defsh);
	printf("  -L rlimspec: set resource limits (ulimit). rlimspec: nrlim:soft:hard\n");
	printf("  -M pat str: do a test fnmatch(3) of pat to str\n");
	printf("  -n: never ask for password. If password is required, return an error\n");
	printf("  -p: print command line which will be run\n");
	printf("  -P: preserve provided environment\n");
	printf("  -Q prio: set process priority to prio\n");
	printf("  -r: always try to lookup numeric names in database\n");
	printf("  -R dir: chroot into dir\n");
	printf("  -v: show more info about what is going to be run and as whom\n");
	printf("  -V: show version information\n\n");
	printf(" By default, if user specified, group id and group list are set to target user is in.\n");
	printf(" ALWAYS check target permissions with %s -c id executed as target user!\n\n", progname);
	xexit(1);
}

void print_builtin_defs(void)
{
	int x;

	printf("\nCompiled-in defaults:\n");
	printf("default flags: " DEFAULT_FLAGS "\n");
	printf("default spath: " SAFE_PATH "\n");
	printf("default shell: " DEFAULT_SHELL "\n");
#ifdef PATH_LOCKS
	printf("lock files location: " PATH_LOCKS "\n");
	printf("lock files suffix: " PATH_LOCKS_SUF "\n");
#else
	printf("built without lock files support\n");
#endif
	printf("default uid if no args: %u\n", DEF_ID);
	printf("failure delay: %uus\n", DELAY_WRPASS);
	printf("Environment:\n");
	printf("Always kept variables:\n");
	for (x = 0; keepenvv[x]; x += 2) printf("  %s\n", keepenvv[x]);
	printf("Always cleared variables:\n");
	for (x = 0; clearenvv[x]; x++) printf("  %s\n", clearenvv[x]);
	printf("Always cleared variables prefixes:\n");
	for (x = 0; clearpfxenvv[x]; x++) printf("  %s\n", clearpfxenvv[x]);
	printf("Always cleared variables suffixes:\n");
	for (x = 0; clearsufenvv[x]; x++) printf("  %s\n", clearsufenvv[x]);
	printf("\n");
}

void print_uidinfos(char *c_opt_str, int pui_flags)
{
	uid_t tuid, teuid;
	gid_t tgid, tegid;
	char *tusr, *teusr;
	char *tgrp, *tegrp;
	size_t tgsz; gid_t *tgids;
	char *tgrps;
	char *s, *d;
	int x;

	if (isflag(pui_flags, PUI_OPT_g)) {
		tgid = dstgid; tgrp = dstgrp;
		tegid = dstegid; tegrp = dstegrp;
	}
	else {
		tgid = srcgid; tgrp = srcgrp;
		tegid = srcegid; tegrp = srcegrp;
	}

	if (isflag(pui_flags, PUI_OPT_u)) {
		tuid = dstuid; tusr = dstusr;
		teuid = dsteuid; teusr = dsteusr;
		tgsz = dstgsz; tgids = dstgids;
		tgid = dstgid; tgrp = dstgrp;
		tegid = dstegid; tegrp = dstegrp;
	}
	else {
		tuid = srcuid; tusr = srcusr;
		teuid = srceuid; teusr = srceusr;
		tgsz = srcgsz; tgids = srcgids;
		tgid = srcgid; tgrp = srcgrp;
		tegid = srcegid; tegrp = srcegrp;
	}

	s = d = c_opt_str;
	while ((s = strtok(d, ","))) {
		if (d) d = NULL;

		if (!strcmp(s, "id")) {
			printf("uid=%u(%s) ", tuid, tusr);
			if (teuid && tuid != teuid) printf("euid=%u(%s) ", teuid, teusr);
			printf("gid=%u(%s) ", tgid, tgrp);
			if (tgid != tegid) printf("egid=%u(%s) ", tegid, tegrp);
			tgrps = build_usergroups(tgsz, tgids, 1);
			printf("groups=%s\n", tgrps);
			xfree(tgrps);
		}
		else if (!strcmp(s, "uid")) printf("%u\n", tuid);
		else if (!strcmp(s, "gid")) printf("%u\n", tgid);
		else if (!strcmp(s, "euid")) printf("%u\n", teuid);
		else if (!strcmp(s, "egid")) printf("%u\n", tegid);
		else if (!strcmp(s, "user")) printf("%s\n", tusr);
		else if (!strcmp(s, "euser")) printf("%s\n", teusr);
		else if (!strcmp(s, "group")) printf("%s\n", tgrp);
		else if (!strcmp(s, "egroup")) printf("%s\n", tegrp);
		else if (!strcmp(s, "gids")) {
			for (x = 0; x < tgsz - 1; x++) printf("%u ", tgids[x]);
			printf("%u\n", tgids[x]);
		}
		else if (!strcmp(s, "groups")) {
			tgrps = build_usergroups(tgsz, tgids, 0);
			x = 0;
			while (*(tgrps+x)) {
				if (*(tgrps+x) == ',') *(tgrps+x) = ' ';
				x++;
			}
			printf("%s\n", tgrps);
		}
		else if (!strcmp(s, "udir"))
			printf("%s\n", udirbyname(tusr));
		else if (!strcmp(s, "shell"))
			 printf("%s\n", shellbyname(tusr));
		else if (!strcmp(s, "suser")) printf("%s\n", suusr);
		else usage_long();
	}
	xexit(0);
}

void show_version(void)
{
	if (if_quiet) xexit(0);

	printf(NAME ": authenticator for Unix systems\n");
	printf("Version " _SUPER_VERSION "\n");
#ifdef _SUPER_VERGIT
	printf("Git tag " _SUPER_VERGIT "\n");
#endif
	if (issuper() && opt_V_cnt == 2) print_builtin_defs();
	xexit(0);
}
