#include "super.h"

void clear_user_environ(void)
{
	char **env = environ;

	while (*env) {
		*env = NULL;
		env++;
	}
	*environ = NULL;
}

void unset_prefixed_envvars(const char *pfx)
{
	char **env = environ;
	char *tmp, *S;
	size_t pfxl = strnlen(pfx, _ALLOC_MAX);

	tmp = xmalloc(_ALLOC_MAX);

	if (!env) return;
	while (*env) {
		if (!strncmp(pfx, *env, pfxl)) {
			xstrlcpy(tmp, *env, _ALLOC_MAX-1);
			S = strchr(tmp, '=');
			if (S) {
				*S = 0;
				unsetenv(tmp);
			}
		}
		env++;
	}

	xfree(tmp);
}

void unset_suffixed_envvars(const char *suf)
{
	char **env = environ;
	char *tmp, *S;
	size_t sufl = strnlen(suf, _ALLOC_MAX);

	tmp = xmalloc(_ALLOC_MAX);

	if (!env) return;
	while (*env) {
		S = *env; while (*S && *S != '=') S++; if ((S-sufl)-*env > 0) S -= sufl;
		if (!strncmp(suf, S, sufl)) {
			xstrlcpy(tmp, *env, _ALLOC_MAX-1);
			S = strchr(tmp, '=');
			if (S) {
				*S = 0;
				unsetenv(tmp);
			}
		}
		env++;
	}

	xfree(tmp);
}

static int env_kept_always(const char *envname)
{
	int x;

	for (x = 0; keepenvv_always[x]; x++) {
		if (!strncmp(keepenvv_always[x], envname, _ALLOC_MAX)) return 1;
	}

	return 0;
}

#define retn(x) do { xfree(tmp); return x; } while (0)
int cfg_permitted_envvar(const char *envname)
{
	char *s, *d;
	char *tmp = NULL;
	int x;

	if (!envpermit) retn(1); /* always allow, no filter */
	if (env_kept_always(envname)) retn(1);

	if (!envname) retn(0);

	tmp = xmalloc(_ALLOC_MAX);
	xstrlcpy(tmp, envpermit, _ALLOC_MAX-1);

	s = d = tmp; x = 0;
	if (*s == '$') s++;
	while (d) {
_u:		d = strchr(x ? d+1 : s, '$'); x = 0;
		if (d && (d-s && *(d-1) != '\\')) { *d = 0; d++; }
		else if (d) { x = 1; goto _u; }
		s_strrep(s, "\\$", "$");

		if (!strncmp(s, envname, _ALLOC_MAX-(s-tmp))) retn(1);

		s = d;
	}

	retn(0);
}
#undef retn

void keep_envvar(const char *s)
{
	int x;
	char *tmp, *S;
	char **X = keepenvv;

	x = 0;
	while (*X && x < _s(keepenvv)) { X += 2; x += 2; }

	tmp = xmalloc(_ALLOC_MAX);

	xstrlcpy(tmp, s, _ALLOC_MAX-1);
	S = strchr(tmp, '=');
	if (S) *S = 0;
	X[0] = xstrdup(tmp);
	X[1] = xstrdup(S+1);

	xfree(tmp);
}

void drop_envvar(const char *s)
{
	int x;
	char **X = unkeepenvv;

	x = 0;
	while (*X && x < _s(unkeepenvv)) { X++; x++; }
	X[0] = xstrdup(s);
}

int sanevar(const char *s)
{
	if (!strchr(s, '/') && !strchr(s, '%')) return 1;
	return 0;
}

void init_keep_vars(void)
{
	int x;

	for (x = 0; keepenvv_always[x]; x++) {
		keepenvv[x*2] = xstrdup(keepenvv_always[x]);
	}
}

void keep_user_envvars(void)
{
	int x;
	char *y;

	for (x = 0; keepenvv[x]; x += 2) {
		y = getenv(keepenvv[x]);
		if (!keepenvv[x+1] && y) {
			if (sanevar(y)) keepenvv[x+1] = xstrdup(y);
		}
	}
}

void setkeepvars(void)
{
	int x;

	for (x = 0; keepenvv[x]; x += 2)
		if (keepenvv[x+1]) setenv(keepenvv[x], keepenvv[x+1], 1);
	for (x = 0; unkeepenvv[x]; x++) unsetenv(unkeepenvv[x]);
}

void keep_cfg_envvars(char *p)
{
	char **X = keepenvv;
	char *s, *d;
	int x;

	if (!p) return;

	x = 0;
	while (*X && x < _s(keepenvv)) { X += 2; x += 2; }

	s = d = p; x = 0;
	if (*s == '$') s++;
	while (d) {
_sk:		d = strchr(x ? d+1 : s, '$'); x = 0;
		if (d && (d-s && *(d-1) != '\\')) { *d = 0; d++; }
		else if (d) { x = 1; goto _sk; }
		s_strrep(s, "\\$", "$");
		if (getenv(s)) {
			X[0] = xstrdup(s);
			X[1] = xstrdup(getenv(s));
			X += 2;
		}
		s = d;
	}
	X[0] = NULL;
}

void set_cfg_envvars(char *p)
{
	char *s, *d, *t;
	char *tmp;
	int x;

	if (!p) return;

	tmp = xmalloc(_ALLOC_MAX);

	s = d = p; x = 0;
	if (*s == '$') s++;
	while (d) {
_s:		d = strchr(x ? d+1 : s, '$'); x = 0;
		if (d && (d-s && *(d-1) != '\\')) { *d = 0; d++; }
		else if (d) { x = 1; goto _s; }
		s_strrep(s, "\\$", "$");
		t = strchr(s, '=');
		if (t) {
			*t = 0; t++;
			if (isfmtstr(t, 'u', 1, 0)) { xsnprintf(tmp, _SUID_MAX, t, dstuid); t = tmp; }
			else if (isfmtstr(t, 's', 1, 0)) { xsnprintf(tmp, _ALLOC_MAX-1, t, dstusr); t = tmp; }
			setenv(s, t, 1);
		}
		s = d;
	}

	xfree(tmp);
}

void unset_cfg_envvars(char *p)
{
	char *s, *d;
	int x;

	if (!p) return;

	s = d = p; x = 0;
	if (*s == '$') s++;
	while (d) {
_u:		d = strchr(x ? d+1 : s, '$'); x = 0;
		if (d && (d-s && *(d-1) != '\\')) { *d = 0; d++; }
		else if (d) { x = 1; goto _u; }
		s_strrep(s, "\\$", "$");
		unsetenv(s);
		s = d;
	}
}

void unset_ps_envvars(int pfx, char *p)
{
	char *s, *d;
	int x;

	if (!p) return;

	s = d = p; x = 0;
	if (*s == ':') s++;
	while (d) {
_u:		d = strchr(x ? d+1 : s, ':'); x = 0;
		if (d && (d-s && *(d-1) != '\\')) { *d = 0; d++; }
		else if (d) { x = 1; goto _u; }
		s_strrep(s, "\\:", ":");
		pfx ? unset_prefixed_envvars(s) : unset_suffixed_envvars(s);
		s = d;
	}
}

void set_new_environ(const char *sh)
{
	char *s, *tmp;
	int x;

	tmp = xmalloc(_ALLOC_MAX);
	
	if (!isflag(optflags, SI_OPT_P)) { /* If you very very well will ask to keep environment, I will ... */
		setenv("USER", dstusr, 1);
		setenv("LOGNAME", dstusr, 1);
		s = tmp;
		xsnprintf(s, _SUID_MAX, "%u", dstuid);
		setenv("UID", s, 1);
		if (sh) setenv("SHELL", sh, 1);
		setenv("HOME", udirbyname(dstusr), 1);
	}
	
	/* ... but I always strict with dangerous ones. */
	
	if (!*spath) xstrlcpy(spath, SAFE_PATH, sizeof(spath)-1);
	for (x = 0; clearenvv[x]; x++) unsetenv(clearenvv[x]);
	for (x = 0; clearpfxenvv[x]; x++) unset_prefixed_envvars(clearpfxenvv[x]);
	for (x = 0; clearsufenvv[x]; x++) unset_suffixed_envvars(clearsufenvv[x]);
	if (isflag(suflags, S_PATHHOME)) {
		xsnprintf(tmp, _ALLOC_MAX, "%s/bin:%s", udirbyname(dstusr), spath);
		xstrlcpy(spath, tmp, sizeof(spath)-1);
	}
	setenv("PATH", spath, 1);

	/*
	 * if "superid" is in effect, set full info here,
	 * and allow superuser later unset unneeded vars in config
	 */
	if (isflag(suflags, S_SUPERID)) {
		s = tmp;
		xsnprintf(s, _SUID_MAX, "%u", srcuid);
		setenv("SUPER_UID", s, 1);
		setenv("SUPER_USER", srcusr, 1);
		xsnprintf(s, _SUID_MAX, "%u", srcgid);
		setenv("SUPER_GID", s, 1);
		setenv("SUPER_GROUP", srcgrp, 1);
		setenv("SUPER_GROUPS", srcgrps, 1);
	}

	/*
	 * The same if "destid" is specified, but instead
	 * set destination userid information.
	 */
	if (isflag(suflags, S_DESTID)) {
		s = tmp;
		xsnprintf(s, _SUID_MAX, "%u", dstuid);
		setenv("SUPER_D_UID", s, 1);
		xsnprintf(s, _SUID_MAX, "%u", dsteuid);
		setenv("SUPER_D_EUID", s, 1);
		setenv("SUPER_D_USER", dstusr, 1);
		setenv("SUPER_D_EUSER", dsteusr, 1);
		xsnprintf(s, _SUID_MAX, "%u", dstgid);
		setenv("SUPER_D_GID", s, 1);
		xsnprintf(s, _SUID_MAX, "%u", dstegid);
		setenv("SUPER_D_EGID", s, 1);
		setenv("SUPER_D_GROUP", dstgrp, 1);
		setenv("SUPER_D_EGROUP", dstegrp, 1);
		setenv("SUPER_D_GROUPS", dstgrps, 1);
	}

	xfree(tmp);
}
