#ifndef _SUPER_H
#define _SUPER_H

#define NAME "super"

#include "config.h"

#define DEFAULT_FLAGS "pw,log,logfail,minenv,noopt_a,noopt_A,noopt_C,noopt_d,noopt_e,noopt_r,noopt_L,noopt_Q"
#define DEF_ID 0
#define PASSWORD_PROMPT "Password:"
#define DENY_MSG "Permission denied."
#define DELAY_WRPASS 1000000
#define DEFAULT_UMASK 0022

#define _CPPNSTR(x) #x
#define CPPNSTR(x) _CPPNSTR(x)
#define _s(x) (sizeof(x)/sizeof(*x))

#define SDEF_ID CPPNSTR(DEF_ID)

#define _ANYUSR "*"
#define _ANYCMD "<all>"
#define _SAMEUSR "<same>"

#define _XSALLOC_MAX 262144 /* maximum possible memory to get */

#define _ALLOC_MAX 8192 /* _XSALLOC_MAX / 16 */
#define _ALLOC_BUMPER 64
#define _SSALLOC_MAX CPPNSTR(_ALLOC_MAX)
#define _SUID_MAX 22
#define _NUM_MAX 256
#define _CMDLINE_MAX _ALLOC_MAX
#define _SCMDLINE_MAX CPPNSTR(_CMDLINE_MAX)

#define S_PW 1
#define S_LOG 2
#define S_TTY 4
#define S_DSTPW 8
#define S_SUPW 16
#ifdef SYSLOG_SUPPORT
#define S_SYSLOG 32 /* use syslog instead of file */
#endif
#define S_LOGFAIL 64 /* even if nolog, failed attempts still logged */
#define S_FAIL 128 /* This flag will force fail status */
#define S_PATHHOME 256 /* prepend $HOME/bin into $PATH */
#define S_LOGARGV 512 /* log argv command line */
#define S_MINENV 1024 /* reset to minimal environment */
#define S_LOGUTS 2048 /* logfile timestamps are in unix seconds */
#define S_NOEUID 4096
#define S_NOEGID 8192
#define S_USRONLY 0x4000 /* allow to specify only real target user */
#define S_SUPERID 0x8000 /* append srcusr info to target env */
#define S_DESTID 0x10000 /* append dstusr info to target env */
#define S_NOZERO 0x20000 /* deny any zero uid requests */
#define S_NOLOCK 0x40000 /* don't create and test lockfiles */
#define S_WARNUSR 0x80000 /* warn user and show command line to be execute */
#define S_NONID 0x100000 /* do not permit raw uid numbers usage */
#define S_CHEAT 0x200000 /* cheat invoker: execute cmdline as invoker */
#define S_PWINVALOPT 0x400000 /* ask for password on banned cmdline option */

#define SI_OPT_e 1 /* -e option used */
#define SI_OPT_S 2 /* -S */
#define SI_OPT_LOGIN 4 /* one of -il */
#define SI_OPT_I 8 /* -I */
#define SI_OPT_a 16 /* -a */
#define SI_OPT_A 32 /* -A */
#define SI_OPT_P 64 /* -P */
#define SI_OPT_r 128 /* -r */
#define SI_OPT_b 256 /* -b */
#define SI_OPT_B 512 /* -B */
#define SI_OPT_x 1024 /* -x */
#define SI_OPT_n 2048 /* -n */
#define SI_OPT_F 4096 /* -F */
#define SI_OPT_C 8192 /* -C */
#define SI_OPT_dD 0x4000 /* one of -dD */
#define SI_OPT_E 0x8000 /* -E */
#define SI_OPT_X 0x10000 /* -X */
/* 0x20000 */
#define SI_OPT_L 0x40000 /* -L */
#define SI_OPT_Q 0x80000 /* -Q */
#define SI_OPT_p 0x100000 /* -p */
#define SI_OPT_v 0x200000 /* -v */

/* for flags that go into print_userinfos */
#define PUI_OPT_u 1
#define PUI_OPT_g 2

#define M_DUSR 2 /* Is dst user def & matched? */
#define M_DGRP 4 /* dst group? */
#define M_DGPS 8 /* dst groups? */
#define M_DANYUSR 16 /* any dst user? */
#define M_DANYGRP 32 /* any dst group? */
#define M_DANYGPS 64 /* any dst groups? */

#include "port.h"

struct usermap {
	char *user;
	char *hash;
	uid_t uid;
	gid_t gid;
	/* gecos unused */
	char *udir;
	char *shell;
};

#define NGIDS _NUM_MAX
#define NOUID ((uid_t)-1)
#define NOGID ((gid_t)-1)

extern char **environ;

extern int s_quiet;
#define if_quiet (s_quiet && !issuper())

extern pid_t ourpid, parentpid;
extern char super[_ALLOC_MAX], confline[_ALLOC_MAX], logline[_ALLOC_MAX], envline[_ALLOC_MAX];
extern size_t loglinel, envlinel;
extern char binpath[PATH_MAX];
extern FILE *conffile, *logfile;
extern int suflags, optflags, noptflags;
extern char spath[_ALLOC_MAX], logpath[PATH_MAX];
extern char prompt[256], denymsg[256];
extern char *logargv, *logargvaudit, *origenv;
extern char *trigline, *trigflags;
extern uint64_t delay;
extern int minfd, maxfd;
extern mode_t dumask;
#ifdef PATH_LOCKS
extern char *lockfile;
#endif

extern struct termios saneterm;

extern int opt_x_cnt;
extern int opt_V_cnt;
extern struct usermap umap[_NUM_MAX];
extern int umapidx;

extern char *keepenvv_always[];

extern char *keepenvv[_NUM_MAX];
extern char *unkeepenvv[_NUM_MAX];

extern char *clearenvv[];

extern char *clearpfxenvv[];

extern char *clearsufenvv[];

extern char *rlims[_NUM_MAX];

extern uid_t srcuid, srceuid, dstuid, dsteuid;
extern gid_t srcgid, srcegid, dstgid, dstegid, tmpgid;
extern gid_t srcgids[NGIDS], dstgids[NGIDS];
extern gid_t tmpgids[NGIDS];
extern int srcgsz, dstgsz;
extern int tmpgsz;
extern char *srcusr, *srcgrp, *dstusr, *dstgrp;
extern char *srceusr, *srcegrp, *dsteusr, *dstegrp;
extern char *srcgrps, *dstgrps;
extern char *suusr;
extern char *cmdline, *cwd;
extern char *schrootdir, *chrootdir;
extern char *denvset, *denvunset, *denvkeep;
extern char *envset, *envunset, *envkeep;
extern char *dpfxenvunset, *dsufenvunset;
extern char *pfxenvunset, *sufenvunset;
extern char *envpermit;
extern char *linepw;
extern char *forceas;
extern char *auditargv[_NUM_MAX], *auditenvp[_NUM_MAX];
extern char *auditcmd;
extern int auditret;
extern int auditrun;
extern char *fromtty, *tty_name;

extern int auth;

extern char *progname;
extern char *errstr;
extern char defsh[];
extern char defroot[16];

extern int noblame;

/* All our functions */

/* argv.c */

void refine_argv(int *argc, char ***argv, int idx);

/* base64.c */

size_t base64_decode(char *output, size_t outputl, const char *input, size_t inputl);
size_t base64_encode(char *output, const char *input, size_t inputl);

/* cmdline.c */

char *build_cmdline(int argc, char **argv, int format);
char *build_protected_cmdline(int argc, char **argv);
void audit_cmdline(char *p, char **argout, int argrem);
int is_abs_rel_cmdline(const char *cmdline);
char *s_which(const char *progname);

/* conf.c */

#define reset_conf() { if (conffile) rewind(conffile); }
char *get_conf_line(void);
int open_conf(void);
int resolve_flags(const char *sflags, int *SF, int *OF, int *NOF);
int readin_defaults(void);
void readin_usermaps(void);
void set_variable(const char *spec);
void unset_variable(const char *name);
void close_conf(void);

/* crypt.c */

extern char localid[64];
extern unsigned int saltlen, datalen, offset, passes;
extern int noskconf;
char *s_crypt_r(const char *clear, const char *salt, char *output);
char *s_crypt(const char *key, const char *salt);
char *xcrypt(const char *key, const char *salt);

/* date.c */

char *date_now(void);

/* dir.c */

int xchdir(const char *s);
char *xgetcwd(void);

/* env.c */

void clear_user_environ(void);
void unset_prefixed_envvars(const char *pfx);
void unset_suffixed_envvars(const char *suf);
int cfg_permitted_envvar(const char *envname);
void keep_envvar(const char *s);
void drop_envvar(const char *s);
int sanevar(const char *s);
void init_keep_vars(void);
void keep_user_envvars(void);
void setkeepvars(void);
void keep_cfg_envvars(char *p);
void set_cfg_envvars(char *p);
void unset_cfg_envvars(char *p);
void unset_ps_envvars(int pfx, char *p);
void set_new_environ(const char *sh);

/* error.c */

void wipevars(void);
void xexit(int status);
void xerror(const char *f, ...);
void s_error(const char *f, ...);
void xerrexit(const char *f, ...);
void xerrexit_n(const char *progname, const char *f, ...);
void seterr(const char *f, ...);
void reseterr(void);

/* exec.c */

int forkexecve(const char *path, char *const argv[], char *const envp[], pid_t *svpid);
int lhexecvp(const char *file, char *const argv[], int ve);
int execute(const char *p, char *const argv[], int ve);

/* flags.c */

int isflag(int flags, int flag);
void setflag(int *flags, int flag);
void unsetflag(int *flags, int flag);

/* getopt.c */

int getopt(int argc, char * const argv[], const char *optstring);

/* lockfile.c */

int mklockfile(void);
void unlockfile(void);

/* log.c */

void logenv(const char *env);
void vappendlogline(const char *f, va_list ap);
void appendlogline(const char *f, ...);
void startlogline(void);
int endlogline(int warn);
void undolog(void);

/* match.c */

int do_match(void);

/* memory.c */

#define xfree(x) { if (x) x = nfree(x); }
void memzero(void *p, size_t l);
void *xmalloc(size_t n);
void *nmalloc(size_t n);
void *xrealloc(void *p, size_t n);
void *nfree(void *p);

/* pfx.c */

long xpatol(const char *s);

/* pwdb.c */

uid_t uidbyname(const char *name);
gid_t gidbyuid(uid_t uid);
gid_t gidbyname(const char *name);
int getugroups(const char *name, gid_t gr, gid_t *grps, int *ngrps);
char *shellbyname(const char *name);
char *udirbyname(const char *name);
char *namebyuid(uid_t uid);
char *namebygid(gid_t gid);
char *build_usergroups(int size, gid_t *list, int forid);
int match_groups(gid_t gid, int size, gid_t *list);
int match_password(const char *user, const char *secret);
int isnumgrps(const char *S);

/* resetvar.c */

void reset_builtin_defaults(void);
void reset_line_defaults(void);

/* rlimit.c */

void addrlim(const char *rlimspec);
int setrlim(const char *rlimspec);
void setreslimits(void);
#ifndef NORESETRLIMITS
void preserve_user_limits(void);
void reset_user_limits(void);
void restore_user_limits(void);
#endif

/* secure.c */

int issuper(void);
int cfg_permission(const struct stat *st);
void blame(const char *f, ...);
void s_closefrom(int fd);
int runaway(void);
void ttydetach(void);
void blocksleep(int block);
void warnusr(void);

/* signal.c */

void s_sigblock(int n, int block);
void s_sighandler(int n);

/* str.c */

#define newline_to_nul(s, l) char_to_nul(s, l, '\n')
char *s_strndup(const char *s, size_t n);
void s_sstrrep(char *s, size_t l, const char *f, const char *t);
void s_strrep(char *s, const char *f, const char *t);
void char_to_nul(char *s, size_t l, int c);
int iscomment(const char *s);
int xsnprintf(char *s, size_t n, const char *fmt, ...);
size_t xstrlcpy(char *d, const char *s, size_t n);
int xfgets(char *s, size_t n, FILE *f);
char *xastrncat(char **d, const char *s, size_t n);
char *xstrdup(const char *s);

/* strand.c */

unsigned int getrand(unsigned int s, unsigned int d);
char *mksalt(void);

/* su.c */

int su_main(int argc, char **argv, uid_t srcuid, gid_t srcgid, int srcgsz, gid_t *srcgids);

/* test.c */

int isnum(const char *s);
int optr_isnum(const char *s);
int isfmtstr(const char *s, int c, int n, int z);

/* tty.c */

void getpasswd(char *password, size_t pwdlen, const char *fmt, ...);
int fdgetstring(int fd, char *s, size_t n);
char *xttyname(int fd);

/* usage.c */

void usage(void);
void usage_long(void);
void print_builtin_defs(void);
void print_uidinfos(char *c_opt_str, int pui_flags);
void show_version(void);

/* usermap.c */

char *usermap_gethash(const char *user);
uid_t usermap_getuid(const char *user);
gid_t usermap_getgid(const char *user);
char *usermap_getudir(const char *user);
char *usermap_getushell(const char *user);
char *usermap_getnamebyuid(uid_t uid);
gid_t usermap_getgidbyuid(uid_t uid);

#endif /* _SUPER_H */
