/* version.h   */

#ifndef VERSION_H
#define VERSION_H
			/* retail */
/*#define DEBUG_PARTITIONS 1 */
#define VERSION_MAJOR 22
#define VERSION_MINOR 8
#define VERSION_EDIT  ""
#define VERSION_DATE "19-Feb-2007"

#endif
